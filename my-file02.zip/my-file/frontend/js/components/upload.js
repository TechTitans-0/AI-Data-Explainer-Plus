// Upload Component - AI Data Explainer+

const Upload = {
    init() {
        this.setupDragAndDrop();
        this.setupFileInput();
    },

    setupDragAndDrop() {
        const uploadArea = document.getElementById('upload-area');
        
        if (!uploadArea) return;

        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        // Highlight drop area
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.remove('dragover');
            });
        });

        // Handle dropped files
        uploadArea.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFile(files[0]);
            }
        });
    },

    setupFileInput() {
        const fileInput = document.getElementById('file-input');
        
        if (!fileInput) return;

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFile(e.target.files[0]);
            }
        });
    },

    async handleFile(file) {
        // Validate file
        const validation = Validators.validateFile(file);
        if (!validation.valid) {
            validation.errors.forEach(error => {
                Toast.show(error, 'error');
            });
            return;
        }

        // Show loading state
        this.showLoading();

        try {
            // Upload file to backend
            const response = await API.upload(file);
            
            if (response.success) {
                // Store session data
                App.state.dataset = response.data;
                App.state.sessionId = response.sessionId;

                // Show success message
                Toast.show('File uploaded successfully!', 'success');

                // Update UI with dataset info
                this.updateDatasetOverview(response.data);

                // Navigate to overview section
                App.navigateToSection('overview');

                // Trigger analysis
                await this.triggerAnalysis(response.sessionId);
            } else {
                throw new Error(response.error || 'Upload failed');
            }
        } catch (error) {
            console.error('Upload error:', error);
            Toast.show('Failed to upload file. Please try again.', 'error');
            this.resetUploadArea();
        }
    },

    showLoading() {
        const uploadArea = document.getElementById('upload-area');
        if (uploadArea) {
            uploadArea.innerHTML = `
                <div class="upload-content">
                    <div class="spinner"></div>
                    <h3>Uploading and analyzing...</h3>
                    <p>Please wait while we process your file</p>
                </div>
            `;
        }
    },

    resetUploadArea() {
        const uploadArea = document.getElementById('upload-area');
        if (uploadArea) {
            uploadArea.innerHTML = `
                <div class="upload-content">
                    <i class="fas fa-cloud-upload-alt upload-icon"></i>
                    <h3>Drag & Drop your file here</h3>
                    <p>or</p>
                    <button class="btn-primary" onclick="document.getElementById('file-input').click()">
                        <i class="fas fa-folder-open"></i>
                        Browse Files
                    </button>
                    <input type="file" id="file-input" accept=".csv,.xlsx" hidden>
                    <p class="upload-info">Supported formats: CSV, Excel (.xlsx) | Max size: 10MB</p>
                </div>
            `;
            this.setupDragAndDrop();
            this.setupFileInput();
        }
    },

    updateDatasetOverview(data) {
        const overviewCards = document.getElementById('overview-cards');
        if (overviewCards && data.metadata) {
            const meta = data.metadata;
            overviewCards.innerHTML = `
                <div class="card">
                    <div class="card-icon"><i class="fas fa-table"></i></div>
                    <div class="card-content">
                        <div class="card-value">${Formatters.formatNumber(meta.rows)}</div>
                        <div class="card-label">Total Rows</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon"><i class="fas fa-columns"></i></div>
                    <div class="card-content">
                        <div class="card-value">${Formatters.formatNumber(meta.columns)}</div>
                        <div class="card-label">Total Columns</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon"><i class="fas fa-database"></i></div>
                    <div class="card-content">
                        <div class="card-value">${Formatters.formatBytes(meta.fileSize)}</div>
                        <div class="card-label">File Size</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="card-content">
                        <div class="card-value">${meta.columnNames.length}</div>
                        <div class="card-label">Columns</div>
                    </div>
                </div>
            `;
        }

        // Update data preview
        const dataPreview = document.getElementById('data-preview');
        if (dataPreview && data.preview) {
            const headers = data.preview[0] ? Object.keys(data.preview[0]) : [];
            const rows = data.preview.slice(0, 5);
            
            dataPreview.innerHTML = `
                <div class="preview-table">
                    <table>
                        <thead>
                            <tr>
                                ${headers.map(h => `<th>${h}</th>`).join('')}
                            </tr>
                        </thead>
                        <tbody>
                            ${rows.map(row => `
                                <tr>
                                    ${headers.map(h => `<td>${row[h] !== undefined ? row[h] : 'N/A'}</td>`).join('')}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }
    },

    async triggerAnalysis(sessionId) {
        try {
            const response = await API.analyze(sessionId);
            if (response.success) {
                // Generate charts
                ChartService.generateCharts(response.data);
                
                // Enable chat
                Chat.enable(sessionId);
                
                // Enable report generation
                document.getElementById('generate-report').disabled = false;
                
                Toast.show('Analysis complete!', 'success');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            Toast.show('Analysis failed. Please try again.', 'error');
        }
    }
};

// Initialize upload component when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    Upload.init();
});
