// Report Service - AI Data Explainer+

const ReportService = {
    async generate(sessionId) {
        if (!sessionId) {
            throw new Error('No active session');
        }

        try {
            const response = await API.generateReport(sessionId);
            if (response.success) {
                return response.data;
            }
            throw new Error(response.error || 'Report generation failed');
        } catch (error) {
            console.error('Report generation error:', error);
            throw error;
        }
    },

    download(reportUrl, filename) {
        const link = document.createElement('a');
        link.href = reportUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};
