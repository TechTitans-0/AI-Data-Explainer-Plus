// Chat Controller - AI Data Explainer+

const aiService = require('../services/aiService');
const sessionManager = require('../utils/sessionManager');
const chatHistoryManager = require('../utils/chatHistoryManager');
const constants = require('../config/constants');

class ChatController {
    async chat(req, res) {
        try {
            const { sessionId, question } = req.body;

            // Get session data
            const session = sessionManager.getSession(sessionId);
            if (!session) {
                return res.status(404).json({
                    success: false,
                    error: constants.ERRORS.SESSION_NOT_FOUND
                });
            }

            // Set up SSE
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache');
            res.setHeader('Connection', 'keep-alive');
            res.setHeader('X-Accel-Buffering', 'no'); // Disable nginx buffering

            // Stream AI response
            await aiService.chatWithDataset(session, question, (chunk) => {
                if (chunk) {
                    res.write(`data: ${JSON.stringify({ type: 'chunk', content: chunk })}\n\n`);
                }
            });

            // Send completion signal
            res.write(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
            res.end();
        } catch (error) {
            console.error('Chat error:', error);
            if (!res.headersSent) {
                res.status(500).json({
                    success: false,
                    error: error.message || constants.ERRORS.AI_PROVIDER_UNAVAILABLE
                });
            }
        }
    }

    async getHistory(req, res) {
        try {
            const { sessionId } = req.params;

            const history = chatHistoryManager.getHistory(sessionId);

            res.json({
                success: true,
                history
            });
        } catch (error) {
            console.error('Get chat history error:', error);
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }

    async clearHistory(req, res) {
        try {
            const { sessionId } = req.params;

            chatHistoryManager.clearHistory(sessionId);

            res.json({
                success: true,
                message: 'Chat history cleared'
            });
        } catch (error) {
            console.error('Clear chat history error:', error);
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
}

module.exports = new ChatController();
