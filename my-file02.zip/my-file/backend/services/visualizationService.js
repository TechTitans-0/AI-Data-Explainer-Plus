// Visualization Service - AI Data Explainer+

class VisualizationService {
    generateChartConfigurations(dataset) {
        const { data, metadata } = dataset;
        const charts = [];

        // Generate chart configurations based on data types
        Object.keys(metadata.columnTypes).forEach(col => {
            const type = metadata.columnTypes[col];

            if (type === 'categorical') {
                // Bar chart for categorical data
                charts.push({
                    type: 'bar',
                    column: col,
                    config: this.generateBarChartConfig(data, col)
                });

                // Pie chart if unique values < 10
                if (metadata.uniqueValues[col] < 10) {
                    charts.push({
                        type: 'pie',
                        column: col,
                        config: this.generatePieChartConfig(data, col)
                    });
                }
            } else if (type === 'numeric') {
                // Histogram for numeric data
                charts.push({
                    type: 'histogram',
                    column: col,
                    config: this.generateHistogramConfig(data, col)
                });
            }
        });

        // Generate correlation heatmap if multiple numeric columns
        const numericColumns = Object.keys(metadata.columnTypes).filter(
            col => metadata.columnTypes[col] === 'numeric'
        );

        if (numericColumns.length >= 2) {
            charts.push({
                type: 'heatmap',
                columns: numericColumns,
                config: this.generateCorrelationConfig(data, numericColumns)
            });
        }

        return charts;
    }

    generateBarChartConfig(data, column) {
        const values = data.map(row => row[column]);
        const frequency = {};

        values.forEach(v => {
            frequency[v] = (frequency[v] || 0) + 1;
        });

        return {
            labels: Object.keys(frequency),
            data: Object.values(frequency)
        };
    }

    generatePieChartConfig(data, column) {
        const values = data.map(row => row[column]);
        const frequency = {};

        values.forEach(v => {
            frequency[v] = (frequency[v] || 0) + 1;
        });

        return {
            labels: Object.keys(frequency),
            data: Object.values(frequency)
        };
    }

    generateHistogramConfig(data, column) {
        const values = data.map(row => row[column]).filter(v => typeof v === 'number');
        const min = Math.min(...values);
        const max = Math.max(...values);
        const binCount = 10;
        const binSize = (max - min) / binCount;

        const bins = new Array(binCount).fill(0);
        const labels = [];

        for (let i = 0; i < binCount; i++) {
            labels.push(`${(min + i * binSize).toFixed(2)}`);
        }

        values.forEach(v => {
            const binIndex = Math.min(Math.floor((v - min) / binSize), binCount - 1);
            bins[binIndex]++;
        });

        return {
            labels,
            data: bins
        };
    }

    generateCorrelationConfig(data, columns) {
        const correlationMatrix = {};

        columns.forEach(col1 => {
            correlationMatrix[col1] = {};
            columns.forEach(col2 => {
                const values1 = data.map(row => row[col1]).filter(v => typeof v === 'number');
                const values2 = data.map(row => row[col2]).filter(v => typeof v === 'number');
                
                if (values1.length === values2.length && values1.length > 0) {
                    correlationMatrix[col1][col2] = this.calculateCorrelation(values1, values2);
                } else {
                    correlationMatrix[col1][col2] = 0;
                }
            });
        });

        return {
            columns,
            matrix: correlationMatrix
        };
    }

    calculateCorrelation(arr1, arr2) {
        const n = arr1.length;
        const mean1 = arr1.reduce((a, b) => a + b, 0) / n;
        const mean2 = arr2.reduce((a, b) => a + b, 0) / n;

        let num = 0;
        let den1 = 0;
        let den2 = 0;

        for (let i = 0; i < n; i++) {
            const diff1 = arr1[i] - mean1;
            const diff2 = arr2[i] - mean2;
            num += diff1 * diff2;
            den1 += diff1 * diff1;
            den2 += diff2 * diff2;
        }

        return num / Math.sqrt(den1 * den2);
    }
}

module.exports = new VisualizationService();
