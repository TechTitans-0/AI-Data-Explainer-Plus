// AI Service Tests - AI Data Explainer+

const aiService = require('../../services/aiService');

describe('AIService', () => {
    test('should build insights prompt correctly', () => {
        const mockSession = {
            filename: 'test.csv',
            metadata: {
                rows: 100,
                columns: 5,
                columnNames: ['name', 'age', 'score'],
                columnTypes: { name: 'categorical', age: 'numeric', score: 'numeric' }
            },
            preview: [{ name: 'John', age: 25, score: 95 }],
            analysis: {
                statistics: {
                    numeric: {
                        age: { mean: 25, median: 25, mode: 25, min: 20, max: 30, std: 3 }
                    }
                }
            }
        };

        const prompt = aiService.buildInsightsPrompt(mockSession);
        expect(prompt).toContain('AI Data Explainer');
        expect(prompt).toContain(mockSession.filename);
        expect(prompt).toContain('Executive Summary');
    });

    test('should build chat prompt correctly', () => {
        const mockSession = {
            filename: 'test.csv',
            metadata: {
                columnNames: ['name', 'age'],
                columnTypes: { name: 'categorical', age: 'numeric' }
            },
            preview: [{ name: 'John', age: 25 }],
            analysis: null
        };

        const prompt = aiService.buildChatPrompt(mockSession, 'What is the average age?');
        expect(prompt).toContain('What is the average age?');
        expect(prompt).toContain('name');
        expect(prompt).toContain('age');
    });
});
