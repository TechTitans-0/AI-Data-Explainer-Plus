// Chat Component - AI Data Explainer+

const Chat = {
    sessionId: null,
    history: [],

    enable(sessionId) {
        console.log('Chat.enable called with sessionId:', sessionId);
        
        this.sessionId = sessionId;
        const chatInput = document.getElementById('chat-input');
        const chatSend = document.getElementById('chat-send');
        const chatMessages = document.getElementById('chat-messages');

        if (chatInput) {
            chatInput.disabled = false;
            console.log('Chat input enabled');
        }
        
        if (chatSend) {
            chatSend.disabled = false;
            console.log('Chat send button enabled');
        }

        // Clear placeholder
        if (chatMessages) {
            chatMessages.innerHTML = '';
            console.log('Chat placeholder cleared');
            
            // Add welcome message
            this.addMessage('ai', 'Hello! I\'m ready to help you analyze your data. Ask me anything about your dataset.');
        }

        // Setup event listeners (remove existing first to avoid duplicates)
        if (chatSend) {
            const newChatSend = chatSend.cloneNode(true);
            chatSend.parentNode.replaceChild(newChatSend, chatSend);
            newChatSend.addEventListener('click', () => this.sendMessage());
        }

        if (chatInput) {
            const newChatInput = chatInput.cloneNode(true);
            chatInput.parentNode.replaceChild(newChatInput, chatInput);
            newChatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }
        
        console.log('Chat enabled successfully');
    },

    async sendMessage() {
        const chatInput = document.getElementById('chat-input');
        const question = chatInput.value.trim();

        if (!question || !this.sessionId) {
            return;
        }

        // Add user message to chat
        this.addMessage('user', question);

        // Clear input
        chatInput.value = '';

        // Add to history
        this.history.push({ role: 'user', content: question });

        try {
            // Send question to backend
            const response = await API.chat(this.sessionId, question);
            
            // Handle streaming response
            this.handleStreamingResponse(response);
        } catch (error) {
            console.error('Chat error:', error);
            // Fallback to dataset-based response
            this.generateFallbackResponse(question);
        }
    },

    generateFallbackResponse(question) {
        console.log('Generating fallback response for question:', question);
        const dataset = App.state.dataset;
        
        if (!dataset || !dataset.metadata) {
            this.addMessage('ai', 'I apologize, but I\'m unable to connect to the AI service right now. Please try again later or check your AI provider configuration.');
            return;
        }

        const metadata = dataset.metadata;
        const preview = dataset.preview || [];
        const questionLower = question.toLowerCase();
        
        let response = '';
        
        // Generate context-aware responses based on question keywords
        if (questionLower.includes('row') || questionLower.includes('record') || questionLower.includes('count')) {
            response = `The dataset contains ${metadata.rows} rows/records.`;
        } else if (questionLower.includes('column') || questionLower.includes('field')) {
            response = `The dataset has ${metadata.columns} columns: ${metadata.columnNames.slice(0, 5).join(', ')}${metadata.columnNames.length > 5 ? '...' : ''}.`;
        } else if (questionLower.includes('size') || questionLower.includes('file')) {
            response = `The file size is ${this.formatBytes(metadata.fileSize)}.`;
        } else if (questionLower.includes('data') || questionLower.includes('dataset')) {
            response = `This dataset has ${metadata.rows} rows and ${metadata.columns} columns with a file size of ${this.formatBytes(metadata.fileSize)}. The columns are: ${metadata.columnNames.join(', ')}.`;
        } else if (questionLower.includes('help') || questionLower.includes('what can')) {
            response = `I can help you analyze your dataset with ${metadata.rows} rows and ${metadata.columns} columns. You can ask me about row counts, column information, data size, or general dataset statistics. Note: AI-powered analysis is currently unavailable.`;
        } else {
            response = `I apologize, but the AI service is currently unavailable. I can tell you that your dataset has ${metadata.rows} rows and ${metadata.columns} columns. For detailed analysis, please check your AI provider configuration.`;
        }
        
        this.addMessage('ai', response);
    },

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    },

    addMessage(role, content) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${role}`;
        messageDiv.innerHTML = `
            <div class="chat-message-content">
                ${content}
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    },

    async handleStreamingResponse(response) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        
        // Create AI message placeholder
        const chatMessages = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message ai';
        messageDiv.innerHTML = `
            <div class="chat-message-content">
                <span class="typing-indicator">...</span>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        
        const contentDiv = messageDiv.querySelector('.chat-message-content');
        let fullResponse = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = JSON.parse(line.slice(6));
                    
                    if (data.type === 'chunk') {
                        fullResponse += data.content;
                        contentDiv.textContent = fullResponse;
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    } else if (data.type === 'done') {
                        fullResponse = data.fullResponse;
                        contentDiv.textContent = fullResponse;
                        this.history.push({ role: 'ai', content: fullResponse });
                    }
                }
            }
        }

        chatMessages.scrollTop = chatMessages.scrollHeight;
    },

    reset() {
        this.sessionId = null;
        this.history = [];
        
        const chatInput = document.getElementById('chat-input');
        const chatSend = document.getElementById('chat-send');
        const chatMessages = document.getElementById('chat-messages');

        if (chatInput) {
            chatInput.disabled = true;
            chatInput.value = '';
        }
        if (chatSend) chatSend.disabled = true;

        if (chatMessages) {
            chatMessages.innerHTML = `
                <div class="chat-placeholder">
                    <i class="fas fa-comments"></i>
                    <p>Upload a dataset to start chatting</p>
                </div>
            `;
        }
    }
};
