// API Communication Utility - AI Data Explainer+

const API = {
    baseURL: 'http://localhost:3000/api',

    async upload(file) {
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch(`${this.baseURL}/upload`, {
                method: 'POST',
                body: formData
                // Don't set Content-Type header for FormData - browser sets it automatically with boundary
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error || `Upload failed with status ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Upload error:', error);
            console.error('Error details:', {
                message: error.message,
                name: error.name,
                stack: error.stack
            });
            throw error;
        }
    },

    async analyze(sessionId) {
        try {
            console.log('API.analyze called with sessionId:', sessionId);
            
            const response = await fetch(`${this.baseURL}/analyze`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error('Analysis API error:', errorData);
                throw new Error(errorData.error || 'Analysis failed');
            }

            const data = await response.json();
            console.log('Analysis API response:', data);
            return data;
        } catch (error) {
            console.error('Analysis error:', error);
            throw error;
        }
    },

    async getInsights(sessionId) {
        try {
            console.log('API.getInsights called with sessionId:', sessionId);
            
            const response = await fetch(`${this.baseURL}/insights`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error('Insights API error:', errorData);
                throw new Error(errorData.error || 'Insights generation failed');
            }

            const data = await response.json();
            console.log('Insights API response:', data);
            return data;
        } catch (error) {
            console.error('Insights error:', error);
            throw error;
        }
    },

    async chat(sessionId, question) {
        try {
            const response = await fetch(`${this.baseURL}/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId, question })
            });

            if (!response.ok) {
                throw new Error('Chat failed');
            }

            return response;
        } catch (error) {
            console.error('Chat error:', error);
            throw error;
        }
    },

    async getRecommendations(sessionId) {
        try {
            console.log('API.getRecommendations called with sessionId:', sessionId);
            
            const response = await fetch(`${this.baseURL}/recommendations`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error('Recommendations API error:', errorData);
                throw new Error(errorData.error || 'Recommendations generation failed');
            }

            const data = await response.json();
            console.log('Recommendations API response:', data);
            return data;
        } catch (error) {
            console.error('Recommendations error:', error);
            throw error;
        }
    },

    async generateReport(sessionId) {
        try {
            const response = await fetch(`${this.baseURL}/report`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId })
            });

            if (!response.ok) {
                throw new Error('Report generation failed');
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Report error:', error);
            throw error;
        }
    },

    async healthCheck() {
        try {
            const response = await fetch(`${this.baseURL}/health`);
            if (!response.ok) {
                throw new Error('Health check failed');
            }
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Health check error:', error);
            throw error;
        }
    }
};
