// Chart Service - AI Data Explainer+

const ChartService = {
    charts: {},

    generateCharts(analysisData) {
        console.log('ChartService.generateCharts called with:', analysisData);
        
        const container = document.getElementById('charts-container');
        if (!container) {
            console.error('Charts container not found');
            return;
        }

        // Clear existing charts
        this.destroyCharts();
        container.innerHTML = '';

        // Check if we have valid data
        if (!analysisData) {
            console.error('No analysis data provided');
            container.innerHTML = `
                <div class="chart-placeholder">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>No analysis data available</p>
                </div>
            `;
            return;
        }

        try {
            // Generate different chart types
            this.generateBarChart(container, analysisData);
            this.generatePieChart(container, analysisData);
            this.generateLineChart(container, analysisData);
            
            console.log('Charts generated successfully');
        } catch (error) {
            console.error('Error generating charts:', error);
            container.innerHTML = `
                <div class="chart-placeholder warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error generating charts: ${error.message}</p>
                </div>
            `;
        }
    },

    generateBarChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-bar"></i> Distribution</h3>
            <canvas id="bar-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('bar-chart').getContext('2d');
        
        this.charts.bar = new Chart(ctx, {
            type: 'bar',
            data: this.getBarChartData(data),
            options: this.getBarChartOptions()
        });
    },

    generatePieChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-pie"></i> Composition</h3>
            <canvas id="pie-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('pie-chart').getContext('2d');
        
        this.charts.pie = new Chart(ctx, {
            type: 'pie',
            data: this.getPieChartData(data),
            options: this.getPieChartOptions()
        });
    },

    generateLineChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-line"></i> Trends</h3>
            <canvas id="line-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('line-chart').getContext('2d');
        
        this.charts.line = new Chart(ctx, {
            type: 'line',
            data: this.getLineChartData(data),
            options: this.getLineChartOptions()
        });
    },

    getBarChartData(data) {
        console.log('Generating bar chart data from:', data);
        
        // Try to extract actual data from analysis
        let labels = [];
        let values = [];
        
        if (data && data.statistics && data.statistics.numeric) {
            // Use numeric statistics if available
            const numericStats = data.statistics.numeric;
            const columns = Object.keys(numericStats).slice(0, 5); // Take first 5 columns
            
            labels = columns.map(col => col);
            values = columns.map(col => {
                const stats = numericStats[col];
                return stats.mean || stats.max || 0;
            });
        } else if (data && data.metadata && data.metadata.columnNames) {
            // Fallback to column names with random values
            labels = data.metadata.columnNames.slice(0, 5);
            values = labels.map(() => Math.floor(Math.random() * 100));
        } else {
            // Final fallback to sample data
            labels = ['Category A', 'Category B', 'Category C', 'Category D', 'Category E'];
            values = [12, 19, 3, 5, 2];
        }
        
        console.log('Bar chart data:', { labels, values });
        
        return {
            labels,
            datasets: [{
                label: 'Value',
                data: values,
                backgroundColor: [
                    'rgba(99, 102, 241, 0.8)',
                    'rgba(139, 92, 246, 0.8)',
                    'rgba(236, 72, 153, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)'
                ],
                borderColor: [
                    'rgba(99, 102, 241, 1)',
                    'rgba(139, 92, 246, 1)',
                    'rgba(236, 72, 153, 1)',
                    'rgba(16, 185, 129, 1)',
                    'rgba(245, 158, 11, 1)'
                ],
                borderWidth: 1
            }]
        };
    },

    getPieChartData(data) {
        console.log('Generating pie chart data from:', data);
        
        let labels = [];
        let values = [];
        
        if (data && data.statistics && data.statistics.categorical) {
            // Use categorical statistics if available
            const categoricalStats = data.statistics.categorical;
            const columns = Object.keys(categoricalStats).slice(0, 4); // Take first 4 columns
            
            labels = columns.map(col => col);
            values = columns.map(col => {
                const stats = categoricalStats[col];
                // Use unique count as value
                const uniqueCount = stats.unique ? Object.keys(stats.unique).length : 10;
                return uniqueCount;
            });
        } else if (data && data.metadata && data.metadata.columnNames) {
            // Fallback to column names with random values
            labels = data.metadata.columnNames.slice(0, 4);
            values = labels.map(() => Math.floor(Math.random() * 50) + 10);
        } else {
            // Final fallback to sample data
            labels = ['Category A', 'Category B', 'Category C', 'Category D'];
            values = [30, 25, 25, 20];
        }
        
        console.log('Pie chart data:', { labels, values });
        
        return {
            labels,
            datasets: [{
                data: values,
                backgroundColor: [
                    'rgba(99, 102, 241, 0.8)',
                    'rgba(139, 92, 246, 0.8)',
                    'rgba(236, 72, 153, 0.8)',
                    'rgba(16, 185, 129, 0.8)'
                ],
                borderColor: [
                    'rgba(99, 102, 241, 1)',
                    'rgba(139, 92, 246, 1)',
                    'rgba(236, 72, 153, 1)',
                    'rgba(16, 185, 129, 1)'
                ],
                borderWidth: 1
            }]
        };
    },

    getLineChartData(data) {
        console.log('Generating line chart data from:', data);
        
        let labels = [];
        let values = [];
        
        if (data && data.statistics && data.statistics.numeric) {
            // Use numeric statistics to show trends
            const numericStats = data.statistics.numeric;
            const columns = Object.keys(numericStats).slice(0, 6); // Take first 6 columns
            
            labels = columns.map((col, i) => `Col ${i + 1}`);
            values = columns.map(col => {
                const stats = numericStats[col];
                // Use mean as trend value
                return stats.mean || stats.median || 0;
            });
        } else if (data && data.metadata) {
            // Fallback using metadata
            const rowCount = data.metadata.rows || 100;
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
            values = labels.map(() => Math.floor(Math.random() * rowCount / 10));
        } else {
            // Final fallback to sample data
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
            values = [65, 59, 80, 81, 56, 55];
        }
        
        console.log('Line chart data:', { labels, values });
        
        return {
            labels,
            datasets: [{
                label: 'Trend',
                data: values,
                fill: false,
                borderColor: 'rgba(99, 102, 241, 1)',
                backgroundColor: 'rgba(99, 102, 241, 0.8)',
                tension: 0.1
            }]
        };
    },

    getBarChartOptions() {
        return {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        };
    },

    getPieChartOptions() {
        return {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        };
    },

    getLineChartOptions() {
        return {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        };
    },

    destroyCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.destroy();
            }
        });
        this.charts = {};
    }
};
