const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');

let mainWindow;
let serverProcess;

// Start backend server
function startServer() {
  // Skip starting server if in development (backend runs separately)
  if (process.env.NODE_ENV === 'development') {
    console.log('[Electron] Skipping server start - running in dev mode');
    return;
  }

  const serverPath = path.join(__dirname, '..', 'backend', 'server.js');
  serverProcess = spawn('node', [serverPath], {
    env: { ...process.env, NODE_ENV: 'production' }
  });

  serverProcess.stdout.on('data', (data) => {
    console.log(`[Server] ${data}`);
  });

  serverProcess.stderr.on('data', (data) => {
    console.error(`[Server Error] ${data}`);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 700,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    title: 'SecurePrint - Academic Print Monitor',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    show: false,
    backgroundColor: '#f8fafc'
  });

  // Remove menu bar for kiosk-like experience
  Menu.setApplicationMenu(null);

  mainWindow.loadFile(path.join(__dirname, '..', 'frontend', 'pages', 'login.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  startServer();

  // Wait for server to start
  setTimeout(createWindow, 2000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (serverProcess) serverProcess.kill();
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (serverProcess) serverProcess.kill();
});

// IPC Handlers

// Get files from Downloads folder
ipcMain.handle('get-downloads', async () => {
  const downloadsPath = path.join(os.homedir(), 'Downloads');
  try {
    const files = fs.readdirSync(downloadsPath)
      .filter(f => f.endsWith('.pdf'))
      .map(f => ({
        name: f,
        path: path.join(downloadsPath, f),
        size: fs.statSync(path.join(downloadsPath, f)).size,
        modified: fs.statSync(path.join(downloadsPath, f)).mtime
      }))
      .sort((a, b) => b.modified - a.modified);
    return { success: true, files };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

// Browse for file
ipcMain.handle('browse-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
  });
  if (!result.canceled && result.filePaths.length > 0) {
    const filePath = result.filePaths[0];
    return { success: true, path: filePath, name: path.basename(filePath) };
  }
  return { success: false };
});

// Get available printers
ipcMain.handle('get-printers', async () => {
  try {
    const printers = mainWindow.webContents.getPrintersAsync 
      ? await mainWindow.webContents.getPrintersAsync()
      : mainWindow.webContents.getPrinters();
    return { success: true, printers };
  } catch (e) {
    return { success: true, printers: [{ name: 'Default Printer', isDefault: true }] };
  }
});

// Print file using pdf-to-printer with settings and retry
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

ipcMain.handle('print-file', async (event, { filePath, copies, printer, pageRange, monochrome, duplex }) => {
  try {
    const ptp = require('pdf-to-printer');
    const options = {
      copies: copies || 1,
      printer: printer || undefined,
      pages: pageRange && pageRange !== 'All' ? pageRange : undefined
    };
    if (monochrome) options.monochrome = true;
    if (duplex) options.duplex = duplex;

    let lastError = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await ptp.print(filePath, options);
        return { success: true };
      } catch (err) {
        lastError = err;
        if (attempt < 3) await sleep(1000);
      }
    }
    return { success: false, error: lastError.message };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// Open file externally for preview
ipcMain.handle('preview-file', async (event, filePath) => {
  try {
    await shell.openPath(filePath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

// Navigate to page
ipcMain.handle('navigate', async (event, page) => {
  const pages = {
    login: 'login.html',
    'admin-portal': 'admin-portal.html',
    'forgot-password': 'forgot-password.html',
    'forgot-secret': 'forgot-secret.html',
    'reset-password': 'reset-password.html',
    'reset-secret': 'reset-secret.html',
    'change-password': 'change-password.html',
    faculty: 'faculty-dashboard.html',
    admin: 'admin-dashboard.html',
    'super-admin': 'super-admin-dashboard.html',
    'faculty-management': 'faculty-management.html',
    'client-download': 'client-download.html'
  };
  const file = pages[page];
  console.log('[IPC] Navigate handler called with page:', page, '-> file:', file);
  if (file) {
    console.log('[IPC] Loading file:', path.join(__dirname, '..', 'frontend', 'pages', file));
    mainWindow.loadFile(path.join(__dirname, '..', 'frontend', 'pages', file));
  } else {
    console.log('[IPC] Unknown page:', page);
  }
});

// Get PDF page count
ipcMain.handle('get-pdf-info', async (event, filePath) => {
  try {
    const pdfParse = require('pdf-parse');
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    return { success: true, pages: data.numpages, text: data.text.substring(0, 200) };
  } catch (e) {
    return { success: false, error: e.message, pages: 1 };
  }
});
