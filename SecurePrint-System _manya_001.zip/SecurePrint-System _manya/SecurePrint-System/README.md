# 🖨️ SecurePrint — Academic Print Monitoring System

A secure, role-based desktop application for monitoring and controlling printer usage in academic departments, built with **Electron.js**, **Node.js**, and **MySQL (XAMPP)**.

---

## 📁 Folder Structure

```
print-monitor/
├── backend/
│   ├── config/
│   │   └── database.js          # MySQL/Sequelize connection
│   ├── controllers/
│   │   ├── authController.js    # Register, Login, JWT
│   │   ├── printController.js   # Log prints, usage, reports
│   │   └── adminController.js   # User management, export
│   ├── middleware/
│   │   └── auth.js              # JWT verify, role guards
│   ├── models/
│   │   ├── User.js              # User schema (Sequelize)
│   │   ├── PrintLog.js          # PrintLog schema
│   │   └── index.js             # Associations
│   ├── routes/
│   │   ├── auth.js              # /api/auth/*
│   │   ├── print.js             # /api/print/*
│   │   └── admin.js             # /api/admin/*
│   └── server.js                # Express app entry
├── database/
│   └── schema.sql               # MySQL schema for XAMPP
├── electron/
│   ├── main.js                  # Electron main process
│   └── preload.js               # Secure IPC bridge
├── frontend/
│   ├── assets/
│   │   ├── css/style.css        # Global styles
│   │   └── js/app.js            # Shared JS utilities
│   └── pages/
│       ├── login.html           # Login + Register page
│       ├── faculty-dashboard.html  # Faculty print interface
│       └── admin-dashboard.html    # Admin control panel
├── .env                         # Environment variables
├── package.json
└── README.md
```

---

## ⚙️ Prerequisites

- **XAMPP** (for MySQL) — [Download](https://www.apachefriends.org/)
- **Node.js** v18+ — [Download](https://nodejs.org/)
- **npm** v9+

---

## 🚀 Setup Instructions

### Step 1: Start XAMPP MySQL

1. Open **XAMPP Control Panel**
2. Start **MySQL** (port 3306)
3. Open **phpMyAdmin** → `http://localhost/phpmyadmin`
4. Click **New** → Name it `print_monitor` → Create
5. Click the `print_monitor` database → **SQL tab**
6. Paste contents of `database/schema.sql` → Click **Go**

### Step 2: Install Dependencies

```bash
cd print-monitor
npm install
```

### Step 3: Configure Environment

Edit `.env` file:
```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=print_monitor
DB_USER=root
DB_PASS=          # Leave empty if no XAMPP password
JWT_SECRET=your_super_secret_key_here
RESET_TOKEN_EXPIRES_MS=3600000
```

### Step 4: Run the Application

**Option A: Run everything together**
```bash
npm run dev
```

**Option B: Run separately**
```bash
# Terminal 1 - Backend
node backend/server.js

# Terminal 2 - Electron (after backend starts)
npx electron .
```

---

## 🔐 First Login

### Register as Admin
1. Open the app → Click **Register**
2. Select **Admin** role
3. The very first user can register as admin automatically (no code required)
4. Complete registration

### Register as Faculty
1. Click **Register** → Select **Faculty**
2. Fill in your details

---

## 🌐 API Routes

### Auth Routes (`/api/auth`)
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/login` | Login & get JWT token |
| POST | `/api/auth/forgot-password` | Generate password reset token |
| POST | `/api/auth/reset-password` | Reset password with token |
| POST | `/api/auth/forgot-secret` | Generate secret code reset token |
| POST | `/api/auth/reset-secret` | Reset admin secret code |
| POST | `/api/auth/change-password` | Change password (authenticated) |
| GET | `/api/auth/me` | Get current user profile |

### Print Routes (`/api/print`)
| Method | Route | Access | Description |
|--------|-------|--------|-------------|
| POST | `/api/print/log` | Faculty | Log a print job |
| GET | `/api/print/my-logs` | Faculty | Get own print history |
| GET | `/api/print/admin/all-logs` | Admin | All print logs |
| GET | `/api/print/admin/dashboard` | Admin | Dashboard statistics |
| GET | `/api/print/admin/faculty-report` | Admin | Per-faculty report |

### Admin Routes (`/api/admin`)
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/admin/users` | List all users |
| PUT | `/api/admin/users/:id` | Update user details |
| PUT | `/api/admin/users/:id/toggle` | Activate/deactivate |
| DELETE | `/api/admin/users/:id` | Delete user |
| GET | `/api/admin/export` | Export Excel report |
| GET | `/api/admin/reports` | List stored reports |
| GET | `/api/admin/reports/:id/download` | Download stored report |
| DELETE | `/api/admin/reports/:id` | Delete stored report |

---

## 🔒 Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT (8hr expiry) |
| Password Hashing | bcrypt (12 rounds) |
| Role-Based Access | Middleware guards |
| Auto Logout | 15-min inactivity timer |
| Rate Limiting | 10 login attempts / 15 min |
| Input Validation | Server-side validation |
| Menu Disabled | No browser/dev tools access |
| Secure IPC | Context-isolated preload |

---

## 📊 Database Schema

### `users` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT AUTO_INCREMENT | Primary key |
| name | VARCHAR(100) | Full name |
| email | VARCHAR(150) UNIQUE | Login email |
| password | VARCHAR(255) | bcrypt hash |
| role | ENUM(faculty,admin) | User role |
| department | VARCHAR(100) | Department name |
| employee_id | VARCHAR(50) UNIQUE | Staff ID |
| is_active | TINYINT | Account status |
| last_login | DATETIME | Last login time |

### `print_logs` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT AUTO_INCREMENT | Primary key |
| user_id | INT (FK) | References users.id |
| file_name | VARCHAR(255) | Document name |
| num_pages | INT | Pages in document |
| copies | INT | Number of copies |
| total_sheets | INT | pages × copies |
| page_range | VARCHAR(100) | e.g. "1-5, 8" |
| printer_name | VARCHAR(200) | Printer used |
| status | ENUM | success/failed/cancelled |
| print_month | TINYINT | 1–12 |
| print_year | SMALLINT | e.g. 2024 |
| created_at | DATETIME | Timestamp |

---

## 🛠️ Troubleshooting

**MySQL connection failed:**
- Ensure XAMPP MySQL is running
- Check `.env` `DB_PASS` (empty for default XAMPP)
- Verify database `print_monitor` exists

**Printer not found:**
- The app uses `pdf-to-printer` — ensure a printer is installed
- On Windows: Check Settings → Printers
- The app will still log the job even if printing fails

**Electron won't start:**
- Make sure backend starts first (port 3000)
- Check `npm install` completed without errors

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Desktop App | Electron.js v28 |
| Backend API | Node.js + Express.js |
| Database | MySQL via XAMPP |
| ORM | Sequelize v6 |
| Authentication | JWT + bcryptjs |
| Printing | pdf-to-printer |
| PDF Parsing | pdf-parse |
| Excel Export | xlsx (SheetJS) |
| Charts | Chart.js |
| Styling | Custom CSS (no framework) |

---

*SecurePrint v1.0 — Academic Print Monitoring System*
