
import streamlit as st
import os
from dotenv import load_dotenv
from typing import TypedDict, List
from pydantic import BaseModel, Field, field_validator
from langgraph.graph import StateGraph
from langchain_groq import ChatGroq
from PyPDF2 import PdfReader
import re

# -------------------------------------------------
# PAGE CONFIG
# -------------------------------------------------
st.set_page_config(
    page_title="HireGenAI",
    layout="wide"
)

# Dark professional styling
st.markdown("""
<style>
.stApp {
    background-color: #0f172a;
    color: #f1f5f9;
}
h1, h2, h3, h4 {
    color: #e2e8f0;
}
div[data-testid="stMetricValue"] {
    color: #38bdf8;
}
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# LOAD API KEY
# -------------------------------------------------
load_dotenv()

if "GROQ_API_KEY" not in os.environ:
    st.error("Please set GROQ_API_KEY in .env file")
    st.stop()

# -------------------------------------------------
# LLM INIT - Using Groq with working model
# -------------------------------------------------
llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0.2,
    api_key=os.environ["GROQ_API_KEY"]
)

# -------------------------------------------------
# MODELS WITH BETTER VALIDATION
# -------------------------------------------------
class ResumeData(BaseModel):
    name: str = Field(default="Unknown")
    skills: List[str] = Field(default_factory=list)
    experience_years: float = Field(default=0.0)
    education: str = Field(default="Not specified")
    
    @field_validator('experience_years', mode='before')
    @classmethod
    def validate_experience(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            if match:
                return float(match.group(1))
            return 0.0
        return 0.0
    
    @field_validator('skills', mode='before')
    @classmethod
    def validate_skills(cls, v):
        if isinstance(v, str):
            return [skill.strip() for skill in v.split(',') if skill.strip()]
        if isinstance(v, list):
            return v
        return []


class JDData(BaseModel):
    required_skills: List[str] = Field(default_factory=list)
    min_experience: float = Field(default=0.0)
    role: str = Field(default="Unknown Role")
    
    @field_validator('min_experience', mode='before')
    @classmethod
    def validate_min_experience(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            if match:
                return float(match.group(1))
            return 0.0
        return 0.0
    
    @field_validator('required_skills', mode='before')
    @classmethod
    def validate_required_skills(cls, v):
        if isinstance(v, str):
            return [skill.strip() for skill in v.split(',') if skill.strip()]
        if isinstance(v, list):
            return v
        return []


class MatchResult(BaseModel):
    skill_match_score: float = Field(default=0.0, ge=0, le=100)
    experience_match_score: float = Field(default=0.0, ge=0, le=100)
    overall_score: float = Field(default=0.0, ge=0, le=100)
    matched_skills: List[str] = Field(default_factory=list)
    missing_skills: List[str] = Field(default_factory=list)
    
    @field_validator('skill_match_score', 'experience_match_score', 'overall_score', mode='before')
    @classmethod
    def validate_scores(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            if match:
                return min(100, max(0, float(match.group(1))))
            return 0.0
        return 0.0
    
    @field_validator('matched_skills', 'missing_skills', mode='before')
    @classmethod
    def validate_skill_lists(cls, v):
        if isinstance(v, str):
            return [skill.strip() for skill in v.split(',') if skill.strip()]
        if isinstance(v, list):
            return v
        return []


class InterviewQuestions(BaseModel):
    questions: List[str] = Field(default_factory=list)
    
    @field_validator('questions', mode='before')
    @classmethod
    def validate_questions(cls, v):
        if isinstance(v, str):
            lines = [line.strip() for line in v.split('\n') if line.strip()]
            questions = []
            for line in lines:
                cleaned = re.sub(r'^\d+\.\s*', '', line)
                if cleaned:
                    questions.append(cleaned)
            return questions if questions else [v]
        if isinstance(v, list):
            return v
        return []


# New model for dynamic AI-generated summaries
class CandidateStrengthSummary(BaseModel):
    bullet_points: List[str] = Field(default_factory=list)
    
    @field_validator('bullet_points', mode='before')
    @classmethod
    def validate_bullet_points(cls, v):
        if isinstance(v, list):
            return v[:3]  # Ensure only 3 points
        if isinstance(v, str):
            # Split by newlines or bullet symbols
            points = re.split(r'\n|•|\-|\*', v)
            points = [p.strip() for p in points if p.strip()]
            return points[:3]
        return []


class CandidateProfessionalSummary(BaseModel):
    summary: str = Field(default="")


# -------------------------------------------------
# STATE
# -------------------------------------------------
class HiringState(TypedDict):
    resume_text: str
    jd_text: str
    resume_data: dict
    jd_data: dict
    match_result: dict
    interview_questions: dict


# -------------------------------------------------
# AGENTS WITH IMPROVED PROMPTS
# -------------------------------------------------
def resume_parser(state: HiringState):
    structured_llm = llm.with_structured_output(ResumeData)
    
    prompt = f"""
    Extract structured resume data from the following text.
    
    IMPORTANT FORMATTING RULES:
    - experience_years must be a number (e.g., 2.5, 3, 0.5)
    - skills must be a list of individual skills
    - Make sure to extract the person's name correctly
    - Extract education degree and field
    
    Resume Text:
    {state['resume_text']}
    
    Return ONLY valid JSON matching the schema.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return {"resume_data": result.model_dump()}
    except Exception as e:
        st.error(f"Error parsing resume: {str(e)}")
        return {"resume_data": ResumeData().model_dump()}


def jd_analyzer(state: HiringState):
    structured_llm = llm.with_structured_output(JDData)
    
    prompt = f"""
    Extract structured job requirements from the following job description.
    
    IMPORTANT FORMATTING RULES:
    - min_experience must be a number (e.g., 2, 3, 5)
    - required_skills must be a list of individual skills
    - role should be the job title
    
    Job Description:
    {state['jd_text']}
    
    Return ONLY valid JSON matching the schema.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return {"jd_data": result.model_dump()}
    except Exception as e:
        st.error(f"Error analyzing job description: {str(e)}")
        return {"jd_data": JDData().model_dump()}


def matching_agent(state: HiringState):
    structured_llm = llm.with_structured_output(MatchResult)
    
    prompt = f"""
    Compare the resume and job description data and calculate match scores.
    
    Resume Data: {state['resume_data']}
    Job Data: {state['jd_data']}
    
    Rules:
    - skill_match_score: percentage of required skills that match (0-100)
    - experience_match_score: 100 if candidate experience >= required, otherwise percentage (candidate_exp / required_exp * 100)
    - overall_score: average of skill and experience scores
    - matched_skills: list of skills from job that appear in resume
    - missing_skills: list of skills from job NOT in resume
    
    Return ONLY valid JSON matching the schema.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return {"match_result": result.model_dump()}
    except Exception as e:
        st.error(f"Error matching candidate: {str(e)}")
        return {"match_result": MatchResult().model_dump()}


def interview_agent(state: HiringState):
    structured_llm = llm.with_structured_output(InterviewQuestions)
    
    prompt = f"""
    Based on the resume and job description, generate 5 personalized technical interview questions.
    
    Resume: {state['resume_data']}
    Job: {state['jd_data']}
    
    Rules:
    - Questions should test both technical skills and experience
    - Focus on areas where candidate has strengths AND weaknesses
    - Include 2-3 questions about missing skills if any
    - Make questions specific to the role and candidate's background
    
    Return ONLY valid JSON with a "questions" array of 5 strings.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return {"interview_questions": result.model_dump()}
    except Exception as e:
        st.error(f"Error generating questions: {str(e)}")
        return {"interview_questions": InterviewQuestions().model_dump()}


# -------------------------------------------------
# DYNAMIC AI-GENERATED FUNCTIONS (NO HARDCODING)
# -------------------------------------------------
def generate_candidate_strengths(resume_data: dict, jd_data: dict, match_result: dict):
    """Dynamically generate AI-powered candidate strengths - NOTHING HARDCODED"""
    
    structured_llm = llm.with_structured_output(CandidateStrengthSummary)
    
    prompt = f"""
    Based on the candidate's profile and job requirements, provide exactly 3 bullet points explaining what makes this candidate impressive for this specific role.
    
    Candidate Resume Data:
    - Name: {resume_data.get('name', 'Unknown')}
    - Skills: {', '.join(resume_data.get('skills', []))}
    - Experience: {resume_data.get('experience_years', 0)} years
    - Education: {resume_data.get('education', 'Not specified')}
    
    Job Requirements:
    - Role: {jd_data.get('role', 'Unknown')}
    - Required Skills: {', '.join(jd_data.get('required_skills', []))}
    - Minimum Experience: {jd_data.get('min_experience', 0)} years
    
    Match Analysis:
    - Skill Match Score: {match_result.get('skill_match_score', 0)}%
    - Matched Skills: {', '.join(match_result.get('matched_skills', []))}
    - Missing Skills: {', '.join(match_result.get('missing_skills', []))}
    
    Instructions:
    - Focus on the candidate's SPECIFIC skills and how they match the job requirements
    - Highlight unique strengths or projects mentioned in their background
    - Be honest about both strengths and areas for growth
    - Make each bullet point insightful and specific, NOT generic
    - Each bullet point should be 1-2 sentences long
    - Format as 3 bullet points
    
    Return ONLY valid JSON with a "bullet_points" array containing 3 strings.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return result.bullet_points
    except Exception as e:
        st.error(f"Error generating strengths: {str(e)}")
        # Return a truly dynamic fallback based on actual data (still not hardcoded)
        return [
            f"Shows {match_result.get('skill_match_score', 0)}% skill match for the {jd_data.get('role', 'role')} position",
            f"Brings {resume_data.get('experience_years', 0)} years of relevant experience",
            f"Has expertise in {', '.join(match_result.get('matched_skills', [])[:3])}"
        ]


def generate_professional_summary(resume_data: dict, jd_data: dict, match_result: dict, final_score: float):
    """Dynamically generate AI-powered professional summary - NOTHING HARDCODED"""
    
    structured_llm = llm.with_structured_output(CandidateProfessionalSummary)
    
    prompt = f"""
    Write a professional, concise paragraph (3-4 sentences) explaining why this specific candidate is ideal for the role.
    
    Candidate Information:
    - Name: {resume_data.get('name', 'Candidate')}
    - Skills: {', '.join(resume_data.get('skills', []))}
    - Experience: {resume_data.get('experience_years', 0)} years
    - Education: {resume_data.get('education', 'Not specified')}
    
    Job Requirements:
    - Role: {jd_data.get('role', 'the position')}
    - Required Skills: {', '.join(jd_data.get('required_skills', []))}
    - Minimum Experience Required: {jd_data.get('min_experience', 0)} years
    
    Match Results:
    - Match Score: {final_score}%
    - Skill Match: {match_result.get('skill_match_score', 0)}%
    - Strengths: {', '.join(match_result.get('matched_skills', [])[:5])}
    - Development Areas: {', '.join(match_result.get('missing_skills', [])[:3])}
    
    Instructions:
    - Write in a professional, hiring manager tone
    - Be specific about the candidate's relevant qualifications
    - Mention how their skills align with job requirements
    - Acknowledge any gaps professionally if they exist
    - Keep it to 3-4 sentences maximum
    - Make it unique to this candidate, NOT generic template language
    
    Return ONLY valid JSON with a "summary" string.
    """
    
    try:
        result = structured_llm.invoke(prompt)
        return result.summary
    except Exception as e:
        st.error(f"Error generating summary: {str(e)}")
        # Generate dynamic summary from actual data (still not hardcoded)
        return f"{resume_data.get('name', 'The candidate')} demonstrates a {match_result.get('skill_match_score', 0)}% skill match for the {jd_data.get('role', 'position')} role. With {resume_data.get('experience_years', 0)} years of experience and expertise in {', '.join(match_result.get('matched_skills', [])[:3])}, they are well-positioned to contribute immediately."


# -------------------------------------------------
# GRAPH
# -------------------------------------------------
builder = StateGraph(HiringState)

builder.add_node("resume_parser", resume_parser)
builder.add_node("jd_analyzer", jd_analyzer)
builder.add_node("matching_agent", matching_agent)
builder.add_node("interview_agent", interview_agent)

builder.set_entry_point("resume_parser")
builder.add_edge("resume_parser", "jd_analyzer")
builder.add_edge("jd_analyzer", "matching_agent")
builder.add_edge("matching_agent", "interview_agent")
builder.set_finish_point("interview_agent")

app_graph = builder.compile()

# -------------------------------------------------
# HYBRID SCORE
# -------------------------------------------------
def compute_final_score(candidate):
    try:
        skill_score = float(candidate["match_result"].get("skill_match_score", 0))
        exp_score = float(candidate["match_result"].get("experience_match_score", 0))
        
        education = candidate["resume_data"].get("education", "").lower()
        edu_bonus = 10 if "ai" in education or "ml" in education or "machine learning" in education else 0
        
        final_score = (0.6 * skill_score) + (0.3 * exp_score) + (0.1 * edu_bonus)
        return round(final_score, 2)
    except:
        return 0.0


# -------------------------------------------------
# FILE TEXT EXTRACTION
# -------------------------------------------------
def extract_text_from_file(file):
    try:
        if file.type == "application/pdf":
            pdf = PdfReader(file)
            text = ""
            for page in pdf.pages:
                text += page.extract_text() or ""
            return text
        else:
            return file.read().decode("utf-8")
    except Exception as e:
        st.error(f"Error reading file {file.name}: {str(e)}")
        return ""


# -------------------------------------------------
# UI
# -------------------------------------------------
st.title("🏢✨ HireGenAI — AI Hiring Intelligence Platform")

uploaded_files = st.file_uploader(
    "Upload Resume Files (PDF or TXT)",
    type=["pdf", "txt"],
    accept_multiple_files=True
)

jd_text = st.text_area("Job Description", height=200)

if "ranked_candidates" not in st.session_state:
    st.session_state.ranked_candidates = None

# -------------------------------------------------
# EVALUATE BUTTON
# -------------------------------------------------
if st.button("Evaluate Candidates 🚀"):

    if not uploaded_files:
        st.warning("Please upload at least one resume.")
        st.stop()
    
    if not jd_text.strip():
        st.warning("Please enter a job description.")
        st.stop()

    results = []

    with st.spinner("Analyzing candidates with AI..."):
        progress_bar = st.progress(0)
        for idx, file in enumerate(uploaded_files):
            progress_bar.progress((idx + 1) / len(uploaded_files))
            
            resume_text = extract_text_from_file(file)
            
            if not resume_text:
                st.warning(f"Could not extract text from {file.name}")
                continue

            state = {
                "resume_text": resume_text,
                "jd_text": jd_text,
                "resume_data": {},
                "jd_data": {},
                "match_result": {},
                "interview_questions": {}
            }

            try:
                # Run the main pipeline
                output = app_graph.invoke(state)
                output["final_score"] = compute_final_score(output)
                output["file_name"] = file.name
                
                # Generate DYNAMIC AI summaries (NO HARDCODING)
                output["strength_summary"] = generate_candidate_strengths(
                    output["resume_data"], 
                    output["jd_data"], 
                    output["match_result"]
                )
                output["professional_summary"] = generate_professional_summary(
                    output["resume_data"], 
                    output["jd_data"], 
                    output["match_result"],
                    output["final_score"]
                )
                
                results.append(output)
            except Exception as e:
                st.error(f"Error processing {file.name}: {str(e)}")
        
        progress_bar.empty()

    if results:
        ranked_candidates = sorted(
            results,
            key=lambda x: (
                x["final_score"],
                len(x["match_result"].get("matched_skills", [])),
                x["resume_data"].get("experience_years", 0)
            ),
            reverse=True
        )
        st.session_state.ranked_candidates = ranked_candidates
    else:
        st.error("No candidates were successfully processed.")


# -------------------------------------------------
# DISPLAY RESULTS - FULLY DYNAMIC
# -------------------------------------------------
if st.session_state.ranked_candidates:

    ranked_candidates = st.session_state.ranked_candidates
    top_candidate = ranked_candidates[0]

    st.subheader("🏆 Candidate Ranking Dashboard")

    for i, candidate in enumerate(ranked_candidates, 1):

        name = candidate["resume_data"].get("name", "Unknown")
        score = candidate["final_score"]
        matched = candidate["match_result"].get("matched_skills", [])
        missing = candidate["match_result"].get("missing_skills", [])

        st.markdown(f"### 🥇 Rank {i}: {name}" if i == 1 else f"### Rank {i}: {name}")
        st.metric("Selection Match Percentage", f"{score}%")

        if matched:
            st.write("**Matched Skills:**", ", ".join(matched))
        if missing:
            st.write("**Missing Skills:**", ", ".join(missing))

        # FULLY DYNAMIC AI-GENERATED STRENGTHS - NOTHING HARDCODED
        st.write("**✨ Why This Candidate Stands Out (AI-Generated):**")
        strengths = candidate.get("strength_summary", [])
        if strengths:
            for point in strengths:
                st.write(f"• {point}")
        else:
            st.write("• AI analysis in progress...")

        st.markdown("---")

    # -------------------------------------------------
    # SELECTED CANDIDATE SUMMARY - FULLY DYNAMIC
    # -------------------------------------------------
    st.subheader("📌 Selected Candidate Summary")

    st.success(f"✅ {top_candidate['resume_data'].get('name', 'Candidate')} selected with {top_candidate['final_score']}% match")

    # FULLY DYNAMIC AI-GENERATED PROFESSIONAL SUMMARY - NOTHING HARDCODED
    st.write("**🎯 Why This Candidate is Ideal (AI-Generated):**")
    professional_summary = top_candidate.get("professional_summary", "")
    if professional_summary:
        st.write(professional_summary)
    else:
        st.write("Professional summary being generated...")

    # -------------------------------------------------
    # INTERVIEW PLAN
    # -------------------------------------------------
    st.subheader("💬 Personalized Interview Questions Plan")

    with st.expander("📋 Click to View AI-Generated Interview Questions"):
        questions = top_candidate["interview_questions"].get("questions", [])
        if questions:
            for idx, q in enumerate(questions, 1):
                st.write(f"**{idx}.** {q}")
        else:
            st.write("No interview questions generated.")

    # Optional: Add a regenerate button for dynamic content
    if st.button("🔄 Regenerate AI Analysis for Top Candidate"):
        with st.spinner("Regenerating AI analysis..."):
            top_candidate["strength_summary"] = generate_candidate_strengths(
                top_candidate["resume_data"],
                top_candidate["jd_data"],
                top_candidate["match_result"]
            )
            top_candidate["professional_summary"] = generate_professional_summary(
                top_candidate["resume_data"],
                top_candidate["jd_data"],
                top_candidate["match_result"],
                top_candidate["final_score"]
            )
            st.rerun()