import streamlit as st
import os
import re
import io
import base64
import zipfile
import json
from typing import TypedDict, List
from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator
from langgraph.graph import StateGraph
from langchain_groq import ChatGroq
from PyPDF2 import PdfReader
import docx
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# -------------------------------------------------
# PAGE CONFIG
# -------------------------------------------------
st.set_page_config(
    page_title="HireGenAI",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -------------------------------------------------
# STYLING
# -------------------------------------------------
st.markdown("""
<style>
/* Global palette */
:root {
    --bg: #0f172a;
    --surface: #1e293b;
    --surface-light: #334155;
    --text: #f8fafc;
    --muted: #cbd5e1;
    --accent: #38bdf8;
    --success: #22c55e;
    --warning: #f59e0b;
    --danger: #ef4444;
}

.stApp {
    background-color: var(--bg);
    color: var(--text);
}

h1, h2, h3, h4, h5, h6 {
    color: #e2e8f0 !important;
    font-family: 'Segoe UI', sans-serif;
}

p, div, span, label, .st-emotion-cache-10trblm {
    color: #f1f5f9 !important;
}

/* KPI cards */
.kpi-card {
    background: linear-gradient(135deg, #1e293b, #0f172a);
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 1.25rem;
    text-align: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    margin-bottom: 1rem;
}

.kpi-title {
    color: #94a3b8;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.kpi-value {
    color: #38bdf8;
    font-size: 1.8rem;
    font-weight: 700;
    margin-top: 0.25rem;
}

/* Tables */
.stDataFrame {
    background: #1e293b !important;
}

table {
    border-collapse: collapse;
}
th {
    background: #334155 !important;
    color: #f1f5f9 !important;
}
td {
    color: #f1f5f9 !important;
    border-bottom: 1px solid #334155 !important;
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: #0f172a;
    border-right: 1px solid #1e293b;
}

/* Buttons */
.stButton button {
    border-radius: 8px;
    font-weight: 600;
}

/* Progress bar */
.stProgress .st-bo {
    background-color: #38bdf8;
}
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# LOAD API KEY
# -------------------------------------------------
load_dotenv()

if "GROQ_API_KEY" not in os.environ or not os.environ["GROQ_API_KEY"]:
    st.error("Please set GROQ_API_KEY in the .env file.")
    st.stop()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0.2,
    api_key=os.environ["GROQ_API_KEY"]
)

# -------------------------------------------------
# PYDANTIC MODELS
# -------------------------------------------------
class ResumeData(BaseModel):
    name: str = Field(default="Unknown")
    email: str = Field(default="")
    phone: str = Field(default="")
    skills: List[str] = Field(default_factory=list)
    experience_years: float = Field(default=0.0)
    education: str = Field(default="Not specified")
    education_level: str = Field(default="")
    projects: List[str] = Field(default_factory=list)
    certifications: List[str] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)

    @field_validator('experience_years', mode='before')
    @classmethod
    def validate_experience(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            return float(match.group(1)) if match else 0.0
        return 0.0

    @field_validator('skills', 'projects', 'certifications', 'keywords', mode='before')
    @classmethod
    def validate_lists(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(',') if x.strip()]
        if isinstance(v, list):
            return v
        return []


class JDData(BaseModel):
    role: str = Field(default="Unknown Role")
    required_skills: List[str] = Field(default_factory=list)
    min_experience: float = Field(default=0.0)
    education_requirement: str = Field(default="")
    keywords: List[str] = Field(default_factory=list)
    responsibilities: List[str] = Field(default_factory=list)

    @field_validator('min_experience', mode='before')
    @classmethod
    def validate_min_experience(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            return float(match.group(1)) if match else 0.0
        return 0.0

    @field_validator('required_skills', 'keywords', 'responsibilities', mode='before')
    @classmethod
    def validate_lists(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(',') if x.strip()]
        if isinstance(v, list):
            return v
        return []


class ATSBreakdown(BaseModel):
    skills: float = Field(default=0.0, ge=0, le=100)
    experience: float = Field(default=0.0, ge=0, le=100)
    education: float = Field(default=0.0, ge=0, le=100)
    projects: float = Field(default=0.0, ge=0, le=100)
    certifications: float = Field(default=0.0, ge=0, le=100)
    keywords: float = Field(default=0.0, ge=0, le=100)
    resume_quality: float = Field(default=0.0, ge=0, le=100)

    @field_validator('*', mode='before')
    @classmethod
    def validate_scores(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            return min(100, max(0, float(match.group(1)))) if match else 0.0
        return 0.0


class MatchResult(BaseModel):
    skill_match_score: float = Field(default=0.0, ge=0, le=100)
    experience_match_score: float = Field(default=0.0, ge=0, le=100)
    matched_skills: List[str] = Field(default_factory=list)
    missing_skills: List[str] = Field(default_factory=list)

    @field_validator('skill_match_score', 'experience_match_score', mode='before')
    @classmethod
    def validate_scores(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            match = re.search(r'(\d+(?:\.\d+)?)', v)
            return min(100, max(0, float(match.group(1)))) if match else 0.0
        return 0.0

    @field_validator('matched_skills', 'missing_skills', mode='before')
    @classmethod
    def validate_lists(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(',') if x.strip()]
        if isinstance(v, list):
            return v
        return []


class InterviewQuestions(BaseModel):
    questions: List[str] = Field(default_factory=list)

    @field_validator('questions', mode='before')
    @classmethod
    def validate_questions(cls, v):
        if isinstance(v, str):
            lines = [line.strip() for line in v.split('\n') if line.strip()]
            questions = [re.sub(r'^(\d+\.|\-|\*)\s*', '', line) for line in lines]
            return [q for q in questions if q]
        if isinstance(v, list):
            return v
        return []


class AIEvaluation(BaseModel):
    summary: str = Field(default="")
    matched_skills: List[str] = Field(default_factory=list)
    missing_skills: List[str] = Field(default_factory=list)
    strengths: List[str] = Field(default_factory=list)
    weaknesses: List[str] = Field(default_factory=list)
    skill_gap_analysis: str = Field(default="")
    interview_questions: List[str] = Field(default_factory=list)
    projects_analysis: str = Field(default="")
    certifications_analysis: str = Field(default="")

    @field_validator('matched_skills', 'missing_skills', 'strengths', 'weaknesses', 'interview_questions', mode='before')
    @classmethod
    def validate_lists(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(',') if x.strip()]
        if isinstance(v, list):
            return v
        return []


class AIRecommendation(BaseModel):
    decision: str = Field(default="On Hold")
    confidence: float = Field(default=0.0, ge=0, le=100)
    reason: str = Field(default="")


# -------------------------------------------------
# STATE
# -------------------------------------------------
class HiringState(TypedDict):
    resume_text: str
    jd_text: str
    resume_data: dict
    jd_data: dict
    match_result: dict
    interview_questions: dict
    ats_breakdown: dict
    ai_evaluation: dict
    ai_recommendation: dict


# -------------------------------------------------
# SESSION STATE
# -------------------------------------------------
def init_session():
    defaults = {
        "candidates": [],
        "jobs": [],
        "selected_candidates": [],
        "weights": {
            "skills": 30,
            "experience": 20,
            "education": 15,
            "projects": 10,
            "certifications": 10,
            "keywords": 10,
            "resume_quality": 5
        },
        "processing_stats": {"processed": 0, "skipped": 0, "failed": 0},
        "active_section": "Dashboard",
        "jd_upload_key": 0,
        "resume_upload_key": 0
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

init_session()


# -------------------------------------------------
# FILE EXTRACTION
# -------------------------------------------------
def extract_pdf(file_bytes):
    try:
        pdf = PdfReader(io.BytesIO(file_bytes))
        return "\n".join(page.extract_text() or "" for page in pdf.pages)
    except Exception as e:
        st.error(f"PDF extraction error: {e}")
        return ""


def extract_docx(file_bytes):
    try:
        doc = docx.Document(io.BytesIO(file_bytes))
        return "\n".join([para.text for para in doc.paragraphs if para.text])
    except Exception as e:
        st.error(f"DOCX extraction error: {e}")
        return ""


def extract_txt(file_bytes):
    try:
        return file_bytes.decode("utf-8", errors="ignore")
    except Exception as e:
        st.error(f"TXT extraction error: {e}")
        return ""


def extract_text_from_file(uploaded_file):
    name = uploaded_file.name.lower()
    content = uploaded_file.read()
    uploaded_file.seek(0)
    if name.endswith(".pdf"):
        return extract_pdf(content)
    if name.endswith(".docx"):
        return extract_docx(content)
    if name.endswith(".txt"):
        return extract_txt(content)
    return ""


def extract_zip_files(zip_file):
    extracted_files = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_file.read())) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = info.filename.lower()
                if any(name.endswith(ext) for ext in [".pdf", ".docx", ".txt"]):
                    data = z.read(info.filename)
                    text = ""
                    if name.endswith(".pdf"):
                        text = extract_pdf(data)
                    elif name.endswith(".docx"):
                        text = extract_docx(data)
                    elif name.endswith(".txt"):
                        text = extract_txt(data)
                    if text:
                        extracted_files.append({
                            "name": info.filename.split('/')[-1],
                            "text": text,
                            "content": data,
                            "type": name.split('.')[-1]
                        })
    except Exception as e:
        st.error(f"ZIP extraction error: {e}")
    return extracted_files


# -------------------------------------------------
# LLM AGENTS
# -------------------------------------------------
def resume_parser(state: HiringState):
    structured_llm = llm.with_structured_output(ResumeData)
    prompt = f"""Extract structured resume data from the following text. Be thorough and accurate.

IMPORTANT:
- experience_years must be a number (e.g., 2.5, 3, 0.5)
- skills must be a list of individual technical/professional skills
- education_level: one of High School, Bachelor, Master, Doctorate, Other
- projects: list of project titles or brief descriptions
- certifications: list of certifications
- keywords: important industry keywords and technologies mentioned

Resume Text:
{state['resume_text']}

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"resume_data": result.model_dump()}
    except Exception as e:
        st.error(f"Resume parsing error: {e}")
        return {"resume_data": ResumeData().model_dump()}


def jd_analyzer(state: HiringState):
    structured_llm = llm.with_structured_output(JDData)
    prompt = f"""Extract structured job requirements from the following job description.

IMPORTANT:
- min_experience must be a number
- required_skills must be a list of individual skills
- keywords: important technologies, tools, or domain keywords
- responsibilities: list of key responsibilities

Job Description:
{state['jd_text']}

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"jd_data": result.model_dump()}
    except Exception as e:
        st.error(f"JD analysis error: {e}")
        return {"jd_data": JDData().model_dump()}


def matching_agent(state: HiringState):
    structured_llm = llm.with_structured_output(MatchResult)
    prompt = f"""Compare the resume and job description data. Calculate match scores.

Resume Data: {state['resume_data']}
Job Data: {state['jd_data']}

Rules:
- skill_match_score: percentage of required skills that match (case-insensitive)
- experience_match_score: 100 if candidate experience >= required, else (candidate_exp / required_exp * 100)
- matched_skills: required skills found in resume
- missing_skills: required skills NOT found in resume

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"match_result": result.model_dump()}
    except Exception as e:
        st.error(f"Matching error: {e}")
        return {"match_result": MatchResult().model_dump()}


def interview_agent(state: HiringState):
    structured_llm = llm.with_structured_output(InterviewQuestions)
    prompt = f"""Based on the resume and job description, generate 5 personalized technical interview questions.

Resume: {state['resume_data']}
Job: {state['jd_data']}

Rules:
- Test both technical skills and experience
- Focus on strengths and weaknesses
- Include 2-3 questions about missing skills if any
- Be specific to the role and candidate background

Return valid JSON with a "questions" array of 5 strings.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"interview_questions": result.model_dump()}
    except Exception as e:
        st.error(f"Interview generation error: {e}")
        return {"interview_questions": InterviewQuestions().model_dump()}


def ats_breakdown_agent(state: HiringState):
    structured_llm = llm.with_structured_output(ATSBreakdown)
    prompt = f"""Calculate a detailed ATS score breakdown for the candidate against the job.

Resume Data: {state['resume_data']}
Job Data: {state['jd_data']}
Match Result: {state['match_result']}

For each component, return a score from 0 to 100:
- skills: how well required skills match
- experience: years and relevance
- education: level and relevance to the role
- projects: quality, relevance, and complexity
- certifications: relevance and value
- keywords: presence of important job keywords in resume
- resume_quality: formatting, completeness, and clarity

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"ats_breakdown": result.model_dump()}
    except Exception as e:
        st.error(f"ATS breakdown error: {e}")
        return {"ats_breakdown": ATSBreakdown().model_dump()}


def ai_evaluation_agent(state: HiringState):
    structured_llm = llm.with_structured_output(AIEvaluation)
    prompt = f"""Provide a complete AI evaluation of this candidate for the role.

Resume Data: {state['resume_data']}
Job Data: {state['jd_data']}
Match Result: {state['match_result']}
ATS Breakdown: {state['ats_breakdown']}

Generate:
- summary: professional 3-4 sentence summary
- matched_skills: list of matched skills
- missing_skills: list of missing skills
- strengths: 3-5 candidate strengths
- weaknesses: 3-5 candidate weaknesses
- skill_gap_analysis: paragraph explaining skill gaps and how to address them
- interview_questions: 5 tailored questions
- projects_analysis: 1-2 sentences on project relevance
- certifications_analysis: 1-2 sentences on certification relevance

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"ai_evaluation": result.model_dump()}
    except Exception as e:
        st.error(f"AI evaluation error: {e}")
        return {"ai_evaluation": AIEvaluation().model_dump()}


def ai_recommendation_agent(state: HiringState):
    structured_llm = llm.with_structured_output(AIRecommendation)
    prompt = f"""Recommend the next action for this candidate.

Resume Data: {state['resume_data']}
Job Data: {state['jd_data']}
Match Result: {state['match_result']}
ATS Breakdown: {state['ats_breakdown']}

Decision must be one of: Shortlist, On Hold, Reject.
Confidence is a number 0-100.
Reason: 3-5 sentences explaining the decision, including specific factors for On Hold or Reject candidates.

Return valid JSON matching the schema.
"""
    try:
        result = structured_llm.invoke(prompt)
        return {"ai_recommendation": result.model_dump()}
    except Exception as e:
        st.error(f"Recommendation error: {e}")
        return {"ai_recommendation": AIRecommendation().model_dump()}


# -------------------------------------------------
# LANGGRAPH
# -------------------------------------------------
builder = StateGraph(HiringState)
builder.add_node("resume_parser", resume_parser)
builder.add_node("jd_analyzer", jd_analyzer)
builder.add_node("matching_agent", matching_agent)
builder.add_node("interview_agent", interview_agent)
builder.add_node("ats_breakdown_agent", ats_breakdown_agent)
builder.add_node("ai_evaluation_agent", ai_evaluation_agent)
builder.add_node("ai_recommendation_agent", ai_recommendation_agent)

builder.set_entry_point("resume_parser")
builder.add_edge("resume_parser", "jd_analyzer")
builder.add_edge("jd_analyzer", "matching_agent")
builder.add_edge("matching_agent", "interview_agent")
builder.add_edge("interview_agent", "ats_breakdown_agent")
builder.add_edge("ats_breakdown_agent", "ai_evaluation_agent")
builder.add_edge("ai_evaluation_agent", "ai_recommendation_agent")
builder.set_finish_point("ai_recommendation_agent")

app_graph = builder.compile()


# -------------------------------------------------
# ATS SCORE
# -------------------------------------------------
def compute_ats_score(ats_breakdown, weights):
    if not ats_breakdown:
        return 0.0
    total = 0.0
    for key, weight in weights.items():
        total += ats_breakdown.get(key, 0) * (weight / 100.0)
    return round(total, 2)


def rebalance_weights(changed_key, new_value, weights):
    """Adjust remaining weights so total stays 100."""
    weights = dict(weights)
    weights[changed_key] = new_value
    keys = list(weights.keys())
    others = [k for k in keys if k != changed_key]
    if not others:
        return weights
    current_total = sum(weights.values())
    diff = 100 - current_total
    if diff == 0:
        return weights
    # Distribute diff proportionally
    other_total = sum(weights[k] for k in others)
    if other_total == 0:
        share = diff / len(others)
        for k in others:
            weights[k] = max(0, min(100, weights[k] + share))
    else:
        for k in others:
            weights[k] = max(0, min(100, weights[k] + diff * (weights[k] / other_total)))
    # Normalize to exactly 100
    total = sum(weights.values())
    if total != 100:
        weights[others[0]] += 100 - total
    return {k: round(weights[k], 1) for k in keys}


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def status_color(status):
    return {
        "New": "#94a3b8",
        "AI Evaluated": "#38bdf8",
        "Shortlisted": "#22c55e",
        "Interview Scheduled": "#a855f7",
        "On Hold": "#f59e0b",
        "Rejected": "#ef4444",
        "Selected": "#10b981"
    }.get(status, "#94a3b8")


def decision_color(decision):
    return {
        "Shortlist": "#22c55e",
        "On Hold": "#f59e0b",
        "Reject": "#ef4444"
    }.get(decision, "#94a3b8")


def get_resume_preview_html(candidate):
    file_type = candidate.get("file_type", "txt")
    content = candidate.get("file_content", b"")
    if file_type == "pdf" and content:
        b64 = base64.b64encode(content).decode()
        return f'<iframe src="data:application/pdf;base64,{b64}" width="100%" height="500px" style="border:none;"></iframe>'
    return None


def normalize_skill(skill):
    return re.sub(r"[^a-z0-9]", "", skill.lower())


def skill_match_list(candidate_skills, job_skills):
    matched = []
    missing = []
    norm_candidate = {normalize_skill(s): s for s in candidate_skills}
    for req in job_skills:
        if normalize_skill(req) in norm_candidate:
            matched.append(req)
        else:
            missing.append(req)
    return matched, missing


# -------------------------------------------------
# PIPELINE
# -------------------------------------------------
def evaluate_candidate(file_entry, jobs, weights):
    if not jobs:
        st.warning("No job descriptions available.")
        return None

    best = None
    best_score = -1
    best_role = ""

    for job in jobs:
        state = {
            "resume_text": file_entry["text"],
            "jd_text": job["text"],
            "resume_data": {},
            "jd_data": {},
            "match_result": {},
            "interview_questions": {},
            "ats_breakdown": {},
            "ai_evaluation": {},
            "ai_recommendation": {}
        }
        try:
            output = app_graph.invoke(state)
            ats_breakdown = output.get("ats_breakdown", {})
            score = compute_ats_score(ats_breakdown, weights)
            if score > best_score:
                best = output
                best_score = score
                best_role = output.get("jd_data", {}).get("role", job.get("role", "Unknown"))
        except Exception as e:
            st.error(f"Evaluation error for {file_entry['name']}: {e}")
            continue

    if best is None:
        return None

    candidate = {
        "name": best["resume_data"].get("name", "Unknown"),
        "email": best["resume_data"].get("email", ""),
        "phone": best["resume_data"].get("phone", ""),
        "resume_data": best["resume_data"],
        "match_result": best["match_result"],
        "interview_questions": best["interview_questions"].get("questions", []),
        "ats_breakdown": best["ats_breakdown"],
        "ai_evaluation": best["ai_evaluation"],
        "ai_recommendation": best["ai_recommendation"],
        "jd_data": best["jd_data"],
        "file_name": file_entry["name"],
        "file_content": file_entry.get("content", b""),
        "file_type": file_entry.get("type", "txt"),
        "text": file_entry["text"],
        "best_role": best_role,
        "ats_score": best_score,
        "status": "AI Evaluated",
        "recruiter_decision": best["ai_recommendation"].get("decision", "On Hold"),
        "recruiter_notes": "",
        "recruiter_reason": "",
        "selected_for_comparison": False
    }
    return candidate


# -------------------------------------------------
# UI COMPONENTS
# -------------------------------------------------
def kpi_card(title, value, color="#38bdf8"):
    st.markdown(
        f"""<div class='kpi-card'>
            <div class='kpi-title'>{title}</div>
            <div class='kpi-value' style='color:{color};'>{value}</div>
        </div>""",
        unsafe_allow_html=True
    )


def render_dashboard():
    candidates = st.session_state.candidates
    st.header("Dashboard")
    st.write("Overview of your recruitment pipeline.")

    total = len(candidates)
    avg = round(sum(c["ats_score"] for c in candidates) / total, 1) if total else 0
    shortlisted = sum(1 for c in candidates if c["recruiter_decision"] == "Shortlist" or c["status"] == "Shortlisted")
    on_hold = sum(1 for c in candidates if c["recruiter_decision"] == "On Hold" or c["status"] == "On Hold")
    rejected = sum(1 for c in candidates if c["recruiter_decision"] == "Reject" or c["status"] == "Rejected")
    selected = sum(1 for c in candidates if c["status"] == "Selected")
    interview = sum(1 for c in candidates if c["status"] == "Interview Scheduled")

    cols = st.columns(6)
    with cols[0]: kpi_card("Total Candidates", total)
    with cols[1]: kpi_card("Avg ATS Score", f"{avg}%")
    with cols[2]: kpi_card("Shortlisted", shortlisted, "#22c55e")
    with cols[3]: kpi_card("On Hold", on_hold, "#f59e0b")
    with cols[4]: kpi_card("Rejected", rejected, "#ef4444")
    with cols[5]: kpi_card("Selected", selected, "#10b981")

    if candidates:
        c1, c2 = st.columns(2)
        scores = [c["ats_score"] for c in candidates]
        with c1:
            fig = px.histogram(scores, nbins=10, title="ATS Score Distribution", labels={"value": "ATS Score", "count": "Candidates"}, color_discrete_sequence=["#38bdf8"])
            fig.update_layout(template="plotly_dark", paper_bgcolor="#0f172a", plot_bgcolor="#1e293b")
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            labels = ["Shortlisted", "On Hold", "Rejected", "Selected", "Interview Scheduled"]
            values = [shortlisted, on_hold, rejected, selected, interview]
            colors = ["#22c55e", "#f59e0b", "#ef4444", "#10b981", "#a855f7"]
            fig = go.Figure(go.Funnel(
                y=labels,
                x=values,
                marker=dict(color=colors),
                textposition="inside"
            ))
            fig.update_layout(template="plotly_dark", paper_bgcolor="#0f172a", plot_bgcolor="#1e293b", title="Hiring Funnel")
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Upload resumes and run evaluation to see analytics.")


def render_evaluation():
    st.header("Candidate Evaluation")

    # Job descriptions
    st.subheader("1. Job Descriptions")
    uploaded_jds = st.file_uploader(
        "Upload one or more Job Descriptions (TXT, DOCX, PDF)",
        type=["txt", "docx", "pdf"],
        accept_multiple_files=True,
        key=f"jd_uploader_{st.session_state.jd_upload_key}"
    )

    jd_texts = []
    if uploaded_jds:
        for f in uploaded_jds:
            text = extract_text_from_file(f)
            if text:
                jd_texts.append({"name": f.name, "text": text})
    else:
        # Allow manual paste as a fallback
        jd_input = st.text_area("Or paste a job description here", height=150)
        if jd_input.strip():
            jd_texts.append({"name": "Manual JD", "text": jd_input})

    if jd_texts and st.button("Analyze Job Descriptions", key="analyze_jd"):
        with st.spinner("Analyzing JDs..."):
            jobs = []
            for j in jd_texts:
                state = {"resume_text": "", "jd_text": j["text"], "resume_data": {}, "jd_data": {}, "match_result": {}, "interview_questions": {}, "ats_breakdown": {}, "ai_evaluation": {}, "ai_recommendation": {}}
                try:
                    output = jd_analyzer(state)
                    jd_data = output["jd_data"]
                    jd_data["file_name"] = j["name"]
                    jd_data["text"] = j["text"]
                    jobs.append(jd_data)
                except Exception as e:
                    st.error(f"Error processing {j['name']}: {e}")
            if jobs:
                st.session_state.jobs = jobs
                st.success(f"Analyzed {len(jobs)} job descriptions.")
                for job in jobs:
                    st.write(f"- **{job.get('role', 'Unknown Role')}** ({job['file_name']})")

    if st.session_state.jobs:
        st.markdown("**Available Roles:** " + ", ".join([j.get("role", "Unknown") for j in st.session_state.jobs]))

    # ATS Weights
    st.subheader("2. ATS Weight Configuration")
    st.write("Customize scoring weights. Total must equal 100%.")
    weights = st.session_state.weights
    cols = st.columns(2)
    changed = False
    with cols[0]:
        for key in ["skills", "experience", "education", "projects"]:
            val = st.slider(key.replace("_", " ").title(), 0, 100, int(weights[key]), key=f"weight_{key}")
            if val != weights[key]:
                weights = rebalance_weights(key, val, weights)
                changed = True
    with cols[1]:
        for key in ["certifications", "keywords", "resume_quality"]:
            val = st.slider(key.replace("_", " ").title(), 0, 100, int(weights[key]), key=f"weight_{key}")
            if val != weights[key]:
                weights = rebalance_weights(key, val, weights)
                changed = True
    if changed:
        st.session_state.weights = weights
        # Recalculate all candidate scores
        for c in st.session_state.candidates:
            c["ats_score"] = compute_ats_score(c["ats_breakdown"], weights)
        st.rerun()

    total_weight = sum(weights.values())
    if abs(total_weight - 100) > 0.5:
        st.warning(f"Weights total {total_weight}%. Please adjust to 100%.")
    else:
        st.success(f"Weights total {total_weight}%")

    # Resume upload
    st.subheader("3. Resume Upload")
    uploaded_resumes = st.file_uploader(
        "Upload individual PDF/DOCX/TXT resumes or a ZIP file",
        type=["pdf", "docx", "txt", "zip"],
        accept_multiple_files=True,
        key=f"resume_uploader_{st.session_state.resume_upload_key}"
    )

    if st.session_state.jobs and uploaded_resumes:
        if st.button("Evaluate Candidates", type="primary", key="eval_candidates"):
            files_to_process = []
            stats = {"processed": 0, "skipped": 0, "failed": 0}
            progress_bar = st.progress(0)
            status_text = st.empty()

            # Flatten ZIP and individual files
            for f in uploaded_resumes:
                if f.name.lower().endswith(".zip"):
                    extracted = extract_zip_files(f)
                    files_to_process.extend(extracted)
                else:
                    text = extract_text_from_file(f)
                    content = f.read()
                    if text:
                        files_to_process.append({
                            "name": f.name,
                            "text": text,
                            "content": content,
                            "type": f.name.split('.')[-1].lower()
                        })
                    else:
                        stats["skipped"] += 1

            total_files = len(files_to_process)
            temp_candidates = []
            for i, entry in enumerate(files_to_process):
                status_text.text(f"Processing {entry['name']}... ({i+1}/{total_files})")
                progress_bar.progress((i + 1) / total_files)
                candidate = evaluate_candidate(entry, st.session_state.jobs, st.session_state.weights)
                if candidate:
                    candidate["id"] = len(st.session_state.candidates) + len(temp_candidates) + 1
                    temp_candidates.append(candidate)
                    stats["processed"] += 1
                else:
                    stats["failed"] += 1

            progress_bar.empty()
            status_text.empty()
            st.session_state.processing_stats = stats
            if temp_candidates:
                st.session_state.candidates.extend(temp_candidates)
                st.success(f"Processed {stats['processed']} resumes. Skipped {stats['skipped']}. Failed {stats['failed']}.")
            else:
                st.error("No candidates were successfully evaluated.")
    elif uploaded_resumes and not st.session_state.jobs:
        st.warning("Please analyze at least one job description first.")


def render_candidates():
    st.header("Candidates")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No candidates yet. Evaluate resumes in the 'Candidate Evaluation' section.")
        return

    # Search and filters
    st.subheader("Search & Filters")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        search = st.text_input("Search by name, skill, keyword, or role", key="search")
    with col2:
        status_filter = st.multiselect("Status", options=["New", "AI Evaluated", "Shortlisted", "Interview Scheduled", "On Hold", "Rejected", "Selected"], default=[], key="status_filter")
    with col3:
        role_filter = st.text_input("Job Role", key="role_filter")
    with col4:
        decision_filter = st.multiselect("Recruiter Decision", options=["Shortlist", "On Hold", "Reject"], default=[], key="decision_filter")

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        min_score = st.number_input("Min ATS Score", 0.0, 100.0, 0.0, key="min_score")
    with c2:
        max_score = st.number_input("Max ATS Score", 0.0, 100.0, 100.0, key="max_score")
    with c3:
        skill_filter = st.text_input("Skill contains", key="skill_filter")
    with c4:
        top_n = st.selectbox("Show Top", options=["All", "Top 5", "Top 10", "Top 20"], index=0, key="top_n")

    filtered = candidates[:]
    if search:
        s = search.lower()
        filtered = [c for c in filtered if s in c["name"].lower() or any(s in skill.lower() for skill in c["resume_data"].get("skills", [])) or s in c["text"].lower() or s in c["best_role"].lower()]
    if status_filter:
        filtered = [c for c in filtered if c["status"] in status_filter]
    if decision_filter:
        filtered = [c for c in filtered if c["recruiter_decision"] in decision_filter]
    if role_filter:
        filtered = [c for c in filtered if role_filter.lower() in c["best_role"].lower()]
    if skill_filter:
        filtered = [c for c in filtered if any(skill_filter.lower() in skill.lower() for skill in c["resume_data"].get("skills", []))]
    filtered = [c for c in filtered if min_score <= c["ats_score"] <= max_score]
    filtered = sorted(filtered, key=lambda x: x["ats_score"], reverse=True)

    if top_n == "Top 5":
        filtered = filtered[:5]
    elif top_n == "Top 10":
        filtered = filtered[:10]
    elif top_n == "Top 20":
        filtered = filtered[:20]

    st.write(f"Showing {len(filtered)} of {len(candidates)} candidates")

    # Table
    table_data = []
    for c in filtered:
        table_data.append({
            "Select": c["selected_for_comparison"],
            "Name": c["name"],
            "ATS Score": f"{c['ats_score']}%",
            "Best Role": c["best_role"],
            "Status": c["status"],
            "AI Recommendation": c["ai_recommendation"].get("decision", "On Hold"),
            "Recruiter Decision": c["recruiter_decision"],
            "Actions": c["id"]
        })
    df = pd.DataFrame(table_data)
    st.dataframe(df, use_container_width=True)

    # Bulk compare selection
    selected_ids = st.multiselect("Select candidates for comparison", options=[c["id"] for c in candidates], key="compare_select")
    for c in st.session_state.candidates:
        c["selected_for_comparison"] = c["id"] in selected_ids

    # Expandable details
    st.subheader("Candidate Details")
    for c in filtered:
        with st.expander(f"{c['name']} — ATS {c['ats_score']}% — {c['best_role']} — {c['status']}"):
            tabs = st.tabs(["Overview", "Score Breakdown", "Skills", "AI Recommendation", "Recruiter Decision", "Interview Questions", "Resume Preview"])
            with tabs[0]:
                st.markdown(f"**Email:** {c['resume_data'].get('email', 'N/A')}")
                st.markdown(f"**Phone:** {c['resume_data'].get('phone', 'N/A')}")
                st.markdown(f"**Experience:** {c['resume_data'].get('experience_years', 0)} years")
                st.markdown(f"**Education:** {c['resume_data'].get('education', 'N/A')} ({c['resume_data'].get('education_level', '')})")
                st.markdown(f"**Professional Summary:** {c['ai_evaluation'].get('summary', '')}")
                st.markdown(f"**Resume Quality Score:** {c['ats_breakdown'].get('resume_quality', 0)}%")

            with tabs[1]:
                breakdown = c["ats_breakdown"]
                weights = st.session_state.weights
                for key in ["skills", "experience", "education", "projects", "certifications", "keywords", "resume_quality"]:
                    score = breakdown.get(key, 0)
                    weight = weights.get(key, 0)
                    weighted = round(score * weight / 100, 2)
                    st.write(f"**{key.replace('_', ' ').title()}:** {score}% (weight {weight}%, contribution {weighted}%)")
                st.progress(c["ats_score"] / 100.0)
                st.write(f"**Final ATS Score:** {c['ats_score']}%")

            with tabs[2]:
                st.write("**Matched Skills:**", ", ".join(c["ai_evaluation"].get("matched_skills", [])))
                st.write("**Missing Skills:**", ", ".join(c["ai_evaluation"].get("missing_skills", [])))
                st.write("**Strengths:**")
                for s in c["ai_evaluation"].get("strengths", []):
                    st.write(f"- {s}")
                st.write("**Weaknesses:**")
                for w in c["ai_evaluation"].get("weaknesses", []):
                    st.write(f"- {w}")
                st.write("**Skill Gap Analysis:**", c["ai_evaluation"].get("skill_gap_analysis", ""))

            with tabs[3]:
                rec = c["ai_recommendation"]
                st.markdown(f"**AI Decision:** {rec.get('decision', 'On Hold')}")
                st.markdown(f"**Confidence:** {rec.get('confidence', 0)}%")
                st.markdown(f"**Reason:** {rec.get('reason', '')}")

            with tabs[4]:
                status_options = ["New", "AI Evaluated", "Shortlisted", "Interview Scheduled", "On Hold", "Rejected", "Selected"]
                new_status = st.selectbox("Status", status_options, index=status_options.index(c["status"]) if c["status"] in status_options else 0, key=f"status_{c['id']}")
                decision_options = ["Shortlist", "On Hold", "Reject"]
                new_decision = st.selectbox("Recruiter Decision", decision_options, index=decision_options.index(c["recruiter_decision"]) if c["recruiter_decision"] in decision_options else 0, key=f"decision_{c['id']}")
                notes = st.text_area("Recruiter Notes", value=c["recruiter_notes"], key=f"notes_{c['id']}")
                reason = st.text_area("Decision Reason", value=c["recruiter_reason"], key=f"reason_{c['id']}")
                if st.button("Save Decision", key=f"save_{c['id']}"):
                    c["status"] = new_status
                    c["recruiter_decision"] = new_decision
                    c["recruiter_notes"] = notes
                    c["recruiter_reason"] = reason
                    st.success("Decision saved.")

            with tabs[5]:
                questions = c["ai_evaluation"].get("interview_questions", [])
                for i, q in enumerate(questions, 1):
                    st.write(f"{i}. {q}")

            with tabs[6]:
                preview = get_resume_preview_html(c)
                if preview:
                    st.markdown(preview, unsafe_allow_html=True)
                else:
                    st.text_area("Resume Text", c["text"], height=400)


def render_analytics():
    st.header("Analytics")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No data available.")
        return

    scores = [c["ats_score"] for c in candidates]
    avg = round(sum(scores) / len(scores), 1) if scores else 0

    cols = st.columns(4)
    with cols[0]: kpi_card("Total Candidates", len(candidates))
    with cols[1]: kpi_card("Average ATS Score", f"{avg}%")
    with cols[2]: kpi_card("Highest Score", f"{max(scores)}%" if scores else "0%")
    with cols[3]: kpi_card("Lowest Score", f"{min(scores)}%" if scores else "0%")

    c1, c2 = st.columns(2)
    with c1:
        fig = px.histogram(scores, nbins=10, title="Score Distribution", labels={"value": "ATS Score"}, color_discrete_sequence=["#38bdf8"])
        fig.update_layout(template="plotly_dark", paper_bgcolor="#0f172a", plot_bgcolor="#1e293b")
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        # Skill gap chart
        missing_counts = {}
        for c in candidates:
            for skill in c["ai_evaluation"].get("missing_skills", []):
                missing_counts[skill] = missing_counts.get(skill, 0) + 1
        if missing_counts:
            df = pd.DataFrame({"Skill": list(missing_counts.keys()), "Missing Count": list(missing_counts.values())})
            df = df.sort_values("Missing Count", ascending=False).head(15)
            fig = px.bar(df, x="Missing Count", y="Skill", orientation='h', title="Top Missing Skills", color_discrete_sequence=["#f59e0b"])
            fig.update_layout(template="plotly_dark", paper_bgcolor="#0f172a", plot_bgcolor="#1e293b")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No missing skill data yet.")

    # Funnel
    stages = ["New", "AI Evaluated", "Shortlisted", "Interview Scheduled", "On Hold", "Rejected", "Selected"]
    counts = [sum(1 for c in candidates if c["status"] == s) for s in stages]
    fig = go.Figure(go.Funnel(
        y=stages,
        x=counts,
        marker=dict(color=["#94a3b8", "#38bdf8", "#22c55e", "#a855f7", "#f59e0b", "#ef4444", "#10b981"]),
        textposition="inside"
    ))
    fig.update_layout(template="plotly_dark", paper_bgcolor="#0f172a", plot_bgcolor="#1e293b", title="Hiring Funnel")
    st.plotly_chart(fig, use_container_width=True)


def render_comparison():
    st.header("Candidate Comparison")
    candidates = st.session_state.candidates
    selected = [c for c in candidates if c.get("selected_for_comparison", False)]
    if not selected:
        st.info("Select candidates from the Candidates page to compare.")
        return
    if len(selected) < 2:
        st.warning("Select at least 2 candidates to compare.")
        return

    cols = st.columns(len(selected))
    for c, col in zip(selected, cols):
        with col:
            st.markdown(f"### {c['name']}")
            st.markdown(f"**ATS Score:** {c['ats_score']}%")
            st.markdown(f"**Role:** {c['best_role']}")
            st.markdown(f"**Experience:** {c['resume_data'].get('experience_years', 0)} years")
            st.markdown(f"**Education:** {c['resume_data'].get('education', '')}")
            st.markdown("**Score Breakdown:**")
            for key in ["skills", "experience", "education", "projects", "certifications", "keywords", "resume_quality"]:
                st.markdown(f"- {key.replace('_', ' ').title()}: {c['ats_breakdown'].get(key, 0)}%")
            st.markdown(f"**Matched Skills:** {', '.join(c['ai_evaluation'].get('matched_skills', []))}")
            st.markdown(f"**Missing Skills:** {', '.join(c['ai_evaluation'].get('missing_skills', []))}")
            st.markdown("**Strengths:**")
            for s in c['ai_evaluation'].get('strengths', [])[:3]:
                st.markdown(f"- {s}")
            st.markdown("**Weaknesses:**")
            for w in c['ai_evaluation'].get('weaknesses', [])[:3]:
                st.markdown(f"- {w}")
            st.markdown(f"**AI Recommendation:** {c['ai_recommendation'].get('decision', '')} ({c['ai_recommendation'].get('confidence', 0)}%)")
            st.markdown(f"**Summary:** {c['ai_evaluation'].get('summary', '')[:200]}...")


def render_reports():
    st.header("Reports")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No candidate data to export.")
        return
    export_data = []
    for c in candidates:
        export_data.append({
            "Name": c["name"],
            "Email": c["resume_data"].get("email", ""),
            "Phone": c["resume_data"].get("phone", ""),
            "ATS Score": c["ats_score"],
            "Best Role": c["best_role"],
            "Status": c["status"],
            "AI Recommendation": c["ai_recommendation"].get("decision", ""),
            "AI Confidence": c["ai_recommendation"].get("confidence", ""),
            "Recruiter Decision": c["recruiter_decision"],
            "Matched Skills": ", ".join(c["ai_evaluation"].get("matched_skills", [])),
            "Missing Skills": ", ".join(c["ai_evaluation"].get("missing_skills", [])),
            "Recruiter Notes": c["recruiter_notes"],
            "Recruiter Reason": c["recruiter_reason"]
        })
    df = pd.DataFrame(export_data)
    st.dataframe(df, use_container_width=True)
    csv = df.to_csv(index=False)
    st.download_button("Download CSV Report", csv, "candidates_report.csv", "text/csv")


# -------------------------------------------------
# MAIN APP
# -------------------------------------------------
def main():
    with st.sidebar:
        st.title("🏢 HireGenAI")
        st.markdown("AI Hiring Intelligence Platform")
        st.markdown("---")
        section = st.radio(
            "Navigation",
            options=["Dashboard", "Candidate Evaluation", "Candidates", "Analytics", "Comparison", "Reports", "Settings"]
        )
        st.session_state.active_section = section
        st.markdown("---")
        st.write(f"**Candidates:** {len(st.session_state.candidates)}")
        st.write(f"**Jobs:** {len(st.session_state.jobs)}")

    section = st.session_state.active_section
    if section == "Dashboard":
        render_dashboard()
    elif section == "Candidate Evaluation":
        render_evaluation()
    elif section == "Candidates":
        render_candidates()
    elif section == "Analytics":
        render_analytics()
    elif section == "Comparison":
        render_comparison()
    elif section == "Reports":
        render_reports()
    elif section == "Settings":
        st.header("Settings")
        st.write("Configure default model and behavior.")
        st.info("Model settings and API key management can be added here.")
        if st.button("Reset All Data", key="reset_data"):
            for key in ["candidates", "jobs", "selected_candidates"]:
                st.session_state[key] = []
            st.success("All data reset.")


if __name__ == "__main__":
    main()
