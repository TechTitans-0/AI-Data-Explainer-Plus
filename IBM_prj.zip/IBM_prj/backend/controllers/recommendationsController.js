// Recommendations Controller - AI Data Explainer+

const aiService = require('../services/aiService');
const sessionManager = require('../utils/sessionManager');
const constants = require('../config/constants');

class RecommendationsController {
    async generate(req, res) {
        try {
            const { sessionId } = req.body;

            // Get session data
            const session = sessionManager.getSession(sessionId);
            if (!session) {
                return res.status(404).json({
                    success: false,
                    error: constants.ERRORS.SESSION_NOT_FOUND
                });
            }

            // Generate AI recommendations with fallback
            let recommendations;
            try {
                recommendations = await aiService.generateRecommendations(session);
            } catch (aiError) {
                console.error('AI recommendations error, using fallback:', aiError);
                recommendations = aiService.generateFallbackRecommendations(session);
            }

            // Update session with recommendations
            session.recommendations = recommendations;
            sessionManager.updateSession(sessionId, session);

            res.json({
                success: true,
                data: recommendations
            });
        } catch (error) {
            console.error('Recommendations generation error:', error);
            res.status(500).json({
                success: false,
                error: error.message || constants.ERRORS.AI_PROVIDER_UNAVAILABLE
            });
        }
    }

    generateFallbackRecommendations(session) {
        return aiService.generateFallbackRecommendations(session);
    }
}

module.exports = new RecommendationsController();
