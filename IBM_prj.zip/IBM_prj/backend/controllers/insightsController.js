// Insights Controller - AI Data Explainer+

const aiService = require('../services/aiService');
const sessionManager = require('../utils/sessionManager');
const constants = require('../config/constants');

class InsightsController {
    async generate(req, res) {
        try {
            const { sessionId } = req.body;

            // Get session data
            const session = sessionManager.getSession(sessionId);
            if (!session) {
                return res.status(404).json({
                    success: false,
                    error: constants.ERRORS.SESSION_NOT_FOUND
                });
            }

            // Generate AI insights with fallback
            let insights;
            try {
                insights = await aiService.generateInsights(session);
            } catch (aiError) {
                console.error('AI insights error, using fallback:', aiError);
                insights = aiService.generateFallbackInsights(session);
            }

            // Update session with insights
            session.insights = insights;
            sessionManager.updateSession(sessionId, session);

            res.json({
                success: true,
                data: insights
            });
        } catch (error) {
            console.error('Insights generation error:', error);
            res.status(500).json({
                success: false,
                error: error.message || constants.ERRORS.AI_PROVIDER_UNAVAILABLE
            });
        }
    }

    generateFallbackInsights(session) {
        return aiService.generateFallbackInsights(session);
    }
}

module.exports = new InsightsController();
