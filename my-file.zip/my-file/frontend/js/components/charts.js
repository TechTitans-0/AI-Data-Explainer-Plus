// Chart Component - AI Data Explainer+

const ChartService = {
    charts: {},

    generateCharts(analysisData) {
        const container = document.getElementById('charts-container');
        if (!container) return;

        // Clear placeholder
        container.innerHTML = '';

        // Generate different chart types based on data
        this.generateBarChart(container, analysisData);
        this.generatePieChart(container, analysisData);
        this.generateLineChart(container, analysisData);
    },

    generateBarChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-bar"></i> Distribution</h3>
            <canvas id="bar-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('bar-chart').getContext('2d');
        
        // Sample data - will be replaced with actual data from analysis
        this.charts.bar = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Category A', 'Category B', 'Category C', 'Category D', 'Category E'],
                datasets: [{
                    label: 'Value',
                    data: [12, 19, 3, 5, 2],
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.8)',
                        'rgba(139, 92, 246, 0.8)',
                        'rgba(236, 72, 153, 0.8)',
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(245, 158, 11, 0.8)'
                    ],
                    borderColor: [
                        'rgba(99, 102, 241, 1)',
                        'rgba(139, 92, 246, 1)',
                        'rgba(236, 72, 153, 1)',
                        'rgba(16, 185, 129, 1)',
                        'rgba(245, 158, 11, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    },

    generatePieChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-pie"></i> Composition</h3>
            <canvas id="pie-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('pie-chart').getContext('2d');
        
        this.charts.pie = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Category A', 'Category B', 'Category C', 'Category D'],
                datasets: [{
                    data: [30, 25, 25, 20],
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.8)',
                        'rgba(139, 92, 246, 0.8)',
                        'rgba(236, 72, 153, 0.8)',
                        'rgba(16, 185, 129, 0.8)'
                    ],
                    borderColor: [
                        'rgba(99, 102, 241, 1)',
                        'rgba(139, 92, 246, 1)',
                        'rgba(236, 72, 153, 1)',
                        'rgba(16, 185, 129, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    },

    generateLineChart(container, data) {
        const chartCard = document.createElement('div');
        chartCard.className = 'chart-card';
        chartCard.innerHTML = `
            <h3><i class="fas fa-chart-line"></i> Trends</h3>
            <canvas id="line-chart"></canvas>
        `;
        container.appendChild(chartCard);

        const ctx = document.getElementById('line-chart').getContext('2d');
        
        this.charts.line = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Trend',
                    data: [65, 59, 80, 81, 56, 55],
                    fill: false,
                    borderColor: 'rgba(99, 102, 241, 1)',
                    backgroundColor: 'rgba(99, 102, 241, 0.8)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    },

    destroyCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.destroy();
            }
        });
        this.charts = {};
    }
};
