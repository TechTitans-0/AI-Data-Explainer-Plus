// Upload Middleware - AI Data Explainer+

const multer = require('multer');
const path = require('path');
const env = require('../config/env');
const constants = require('../config/constants');
const { v4: uuidv4 } = require('uuid');

// Configure multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, env.uploadDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename
        const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
        cb(null, uniqueName);
    }
});

// File filter
const fileFilter = (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    
    if (constants.ALLOWED_FILE_EXTENSIONS.includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error(constants.ERRORS.INVALID_FILE_TYPE));
    }
};

// Configure multer
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: constants.MAX_FILE_SIZE
    }
});

module.exports = upload;
