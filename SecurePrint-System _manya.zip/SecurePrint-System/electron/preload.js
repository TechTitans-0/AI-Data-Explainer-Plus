const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getDownloads: () => ipcRenderer.invoke('get-downloads'),
  browseFile: () => ipcRenderer.invoke('browse-file'),
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  printFile: (options) => ipcRenderer.invoke('print-file', options),
  previewFile: (filePath) => ipcRenderer.invoke('preview-file', filePath),
  navigate: (page) => {
    console.log('[ELECTRON] Navigate to:', page);
    return ipcRenderer.invoke('navigate', page);
  },
  getPdfInfo: (filePath) => ipcRenderer.invoke('get-pdf-info', filePath)
});

// Expose secure storage for token
contextBridge.exposeInMainWorld('secureStorage', {
  set: (key, value) => {
    try { localStorage.setItem(key, value); } catch(e) {}
  },
  get: (key) => {
    try { return localStorage.getItem(key); } catch(e) { return null; }
  },
  remove: (key) => {
    try { localStorage.removeItem(key); } catch(e) {}
  },
  clear: () => {
    try { localStorage.clear(); } catch(e) {}
  }
});
