-- ============================================================
-- SecurePrint - Academic Print Monitoring System
-- MySQL Schema for XAMPP / phpMyAdmin
-- Run this in phpMyAdmin's SQL tab or import as .sql file
-- ============================================================

CREATE DATABASE IF NOT EXISTS `print_monitor`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `pmonitor`;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id`                   INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name`                 VARCHAR(100) NOT NULL,
  `email`                VARCHAR(150) NOT NULL UNIQUE,
  `password`             VARCHAR(255) NOT NULL COMMENT 'bcrypt hashed',
  `role`                 ENUM('faculty','admin') NOT NULL DEFAULT 'faculty',
  `department`           VARCHAR(100) DEFAULT NULL,
  `employee_id`          VARCHAR(50) UNIQUE DEFAULT NULL,
  `is_active`            TINYINT(1) NOT NULL DEFAULT 1,
  `last_login`           DATETIME DEFAULT NULL,
  `reset_date`           DATE DEFAULT NULL COMMENT 'Date usage was last reset',
  `created_at`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_email` (`email`),
  INDEX `idx_role`  (`role`),
  INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: print_logs
-- ============================================================
CREATE TABLE IF NOT EXISTS `print_logs` (
  `id`            INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id`       INT NOT NULL,
  `file_name`     VARCHAR(255) NOT NULL,
  `file_path`     TEXT DEFAULT NULL,
  `num_pages`     INT NOT NULL DEFAULT 1,
  `copies`        INT NOT NULL DEFAULT 1,
  `total_sheets`  INT NOT NULL DEFAULT 1 COMMENT 'num_pages * copies',
  `page_range`    VARCHAR(100) DEFAULT 'All',
  `printer_name`  VARCHAR(200) DEFAULT 'Default',
  `status`        ENUM('success','failed','cancelled') NOT NULL DEFAULT 'success',
  `print_month`   TINYINT NOT NULL COMMENT '1-12',
  `print_year`    SMALLINT NOT NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_print_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id`      (`user_id`),
  INDEX `idx_month_year`   (`print_month`, `print_year`),
  INDEX `idx_created_at`   (`created_at`),
  INDEX `idx_status`       (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Sample Admin Account (password: Admin@1234)
-- Run this only once to seed an initial admin
-- ============================================================
INSERT INTO `users`
(`name`, `email`, `password`, `role`, `department`, `employee_id`)
VALUES (
  'System Administrator',
  'admin@institution.edu',
  '$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  'admin',
  'Administration',
  'ADMIN001'
);

-- ============================================================
-- Useful Queries for phpMyAdmin
-- ============================================================

-- View all faculty usage this month:
SELECT 
    u.name, 
    u.department, 
    u.employee_id,
    SUM(pl.total_sheets) AS sheets_used
FROM users u
LEFT JOIN print_logs pl 
    ON u.id = pl.user_id
    AND pl.print_month = MONTH(NOW()) 
    AND pl.print_year = YEAR(NOW()) 
    AND pl.status = 'success'
WHERE u.role = 'faculty'
GROUP BY u.id 
ORDER BY sheets_used DESC;

-- Daily usage for current month:
SELECT 
    DATE(created_at) AS print_date, 
    COUNT(*) AS jobs, 
    SUM(total_sheets) AS sheets
FROM print_logs
WHERE print_month = MONTH(NOW()) 
  AND print_year = YEAR(NOW())
GROUP BY DATE(created_at) 
ORDER BY print_date DESC;
