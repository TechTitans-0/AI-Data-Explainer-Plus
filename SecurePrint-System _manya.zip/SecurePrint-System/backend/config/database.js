const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME || 'pmonitor',
  process.env.DB_USER || 'root',
  process.env.DB_PASS || '',
  {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: false,
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
);

const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ MySQL (XAMPP) connected successfully.');
    await sequelize.sync({ alter: true });
    console.log('✅ Database tables synchronized.');
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    console.error('Make sure XAMPP MySQL is running on port 3306');
    process.exit(1);
  }
};

module.exports = { sequelize, connectDB };
