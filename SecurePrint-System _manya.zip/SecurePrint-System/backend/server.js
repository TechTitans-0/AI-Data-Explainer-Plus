require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
const { connectDB } = require('./config/database');

// Import models to register associations
require('./models/index');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: ['http://localhost:*', 'file://'], credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/print', require('./routes/print'));
app.use('/api/admin', require('./routes/admin'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'SecurePrint API is running', time: new Date() });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// Start server after DB connection
connectDB().then(() => {
  const server = app.listen(PORT, () => {
    console.log(`\n🖨️  SecurePrint Server running on http://localhost:${PORT}`);
    console.log(`📊 Admin Panel: Open Electron app`);
    console.log(`🔑 Admin Code: ${process.env.ADMIN_REGISTRATION_CODE}\n`);
  });

  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`❌ Port ${PORT} is already in use. Please stop the process using it or set a different PORT in .env.`);
      process.exit(1);
    }
    console.error('❌ Server error:', error.message);
    process.exit(1);
  });
});

module.exports = app;
