const { PrintLog, User } = require('../models');
const { Op, fn, col, literal } = require('sequelize');

// POST /api/print/log - Log a print job
const logPrint = async (req, res) => {
  try {
    const { file_name, file_path, num_pages, copies, page_range, printer_name, status } = req.body;
    const user = req.user;

    const totalSheets = (num_pages || 1) * (copies || 1);

    const now = new Date();
    const log = await PrintLog.create({
      user_id: user.id,
      file_name,
      file_path: file_path || null,
      num_pages: num_pages || 1,
      copies: copies || 1,
      total_sheets: totalSheets,
      page_range: page_range || 'All',
      printer_name: printer_name || 'Default',
      status: status || 'success',
      print_month: now.getMonth() + 1,
      print_year: now.getFullYear()
    });

    return res.status(201).json({
      success: true,
      message: 'Print job logged successfully.',
      log
    });
  } catch (error) {
    console.error('Log print error:', error);
    return res.status(500).json({ success: false, message: 'Failed to log print job.' });
  }
};

// GET /api/print/my-logs - Faculty's own logs
const getMyLogs = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const { count, rows } = await PrintLog.findAndCountAll({
      where: { user_id: req.user.id },
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    return res.json({
      success: true,
      logs: rows,
      total: count,
      pages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to fetch logs.' });
  }
};

// GET /api/print/admin/all-logs - Admin: all logs with filters
const getAllLogs = async (req, res) => {
  try {
    const { page = 1, limit = 50, user_id, month, year, status } = req.query;
    const offset = (page - 1) * limit;
    const now = new Date();

    const where = {};
    if (user_id) where.user_id = user_id;
    if (month) where.print_month = month;
    if (year) where.print_year = year;
    if (status) where.status = status;

    const { count, rows } = await PrintLog.findAndCountAll({
      where,
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email', 'department', 'employee_id'] }],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    return res.json({
      success: true,
      logs: rows,
      total: count,
      pages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to fetch logs.' });
  }
};

// GET /api/print/admin/dashboard - Admin dashboard summary
const getDashboardStats = async (req, res) => {
  try {
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const [todaySheets, monthSheets, totalUsers, activeToday] = await Promise.all([
      PrintLog.sum('total_sheets', { where: { created_at: { [Op.gte]: todayStart }, status: 'success' } }),
      PrintLog.sum('total_sheets', { where: { print_month: currentMonth, print_year: currentYear, status: 'success' } }),
      User.count({ where: { role: 'faculty', is_active: true } }),
      PrintLog.count({ where: { created_at: { [Op.gte]: todayStart } }, distinct: true, col: 'user_id' })
    ]);

    // Top users this month
    const topUsers = await PrintLog.findAll({
      where: { print_month: currentMonth, print_year: currentYear, status: 'success' },
      attributes: ['user_id', [fn('SUM', col('total_sheets')), 'total']],
      include: [{ model: User, as: 'user', attributes: ['name', 'department', 'employee_id'] }],
      group: ['user_id', 'user.id'],
      order: [[literal('total'), 'DESC']],
      limit: 5
    });

    // Daily usage last 7 days
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      const dayEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1);
      const sheets = await PrintLog.sum('total_sheets', {
        where: { created_at: { [Op.between]: [dayStart, dayEnd] }, status: 'success' }
      }) || 0;
      last7Days.push({ date: dayStart.toISOString().split('T')[0], sheets });
    }

    return res.json({
      success: true,
      stats: {
        todaySheets: todaySheets || 0,
        monthSheets: monthSheets || 0,
        totalFaculty: totalUsers,
        activeToday: activeToday,
        topUsers,
        dailyTrend: last7Days
      }
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch dashboard stats.' });
  }
};

// GET /api/print/admin/faculty-report - Per faculty report
const getFacultyReport = async (req, res) => {
  try {
    const { month, year } = req.query;
    const now = new Date();
    const targetMonth = month || now.getMonth() + 1;
    const targetYear = year || now.getFullYear();

    const users = await User.findAll({ where: { role: 'faculty', is_active: true } });

    const report = await Promise.all(users.map(async (u) => {
      const totalSheets = await PrintLog.sum('total_sheets', {
        where: { user_id: u.id, print_month: targetMonth, print_year: targetYear, status: 'success' }
      }) || 0;
      const jobCount = await PrintLog.count({
        where: { user_id: u.id, print_month: targetMonth, print_year: targetYear }
      });
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        department: u.department,
        employee_id: u.employee_id,
        totalSheets,
        jobCount
      };
    }));

    return res.json({ success: true, report, month: targetMonth, year: targetYear });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to generate report.' });
  }
};

module.exports = { logPrint, getMyLogs, getAllLogs, getDashboardStats, getFacultyReport };
