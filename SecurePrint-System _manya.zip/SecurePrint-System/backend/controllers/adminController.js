const { User, PrintLog, Report } = require('../models');
const { Op } = require('sequelize');
const xlsx = require('xlsx');

// GET /api/admin/users - List all users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ['password'] },
      order: [['created_at', 'DESC']]
    });
    return res.json({ success: true, users });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to fetch users.' });
  }
};

// PUT /api/admin/users/:id/toggle - Activate/deactivate user
const toggleUserStatus = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    await user.update({ is_active: !user.is_active });
    return res.json({
      success: true,
      message: `User ${user.is_active ? 'activated' : 'deactivated'} successfully.`,
      is_active: user.is_active
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to toggle user status.' });
  }
};

// DELETE /api/admin/users/:id - Delete user
const deleteUser = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    if (user.role === 'admin') return res.status(403).json({ success: false, message: 'Cannot delete admin users.' });

    await PrintLog.destroy({ where: { user_id: user.id } });
    await user.destroy();
    return res.json({ success: true, message: 'User deleted successfully.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to delete user.' });
  }
};

const formatReportWorkbook = (data, summaryData) => {
  const wb = xlsx.utils.book_new();
  const logHeaders = ['S.No', 'Faculty Name', 'Employee ID', 'Department', 'Email', 'File Name', 'Pages', 'Copies', 'Total Sheets', 'Page Range', 'Printer', 'Status', 'Date & Time'];
  const summaryHeaders = ['Faculty Name', 'Employee ID', 'Department', 'Total Sheets Used'];

  const ws1 = xlsx.utils.aoa_to_sheet([logHeaders]);
  const ws2 = xlsx.utils.aoa_to_sheet([summaryHeaders]);

  const headerStyle = { font: { bold: true, color: { rgb: 'FFFFFFFF' } }, fill: { fgColor: { rgb: 'FF2563EB' } }, alignment: { horizontal: 'center' } };
  const range1 = xlsx.utils.decode_range(ws1['!ref'] || 'A1:Z1');
  const range2 = xlsx.utils.decode_range(ws2['!ref'] || 'A1:Z1');

  for (let c = range1.s.c; c <= range1.e.c; c += 1) {
    const cell = ws1[xlsx.utils.encode_cell({ r: range1.s.r, c })];
    if (cell) cell.s = headerStyle;
  }
  for (let c = range2.s.c; c <= range2.e.c; c += 1) {
    const cell = ws2[xlsx.utils.encode_cell({ r: range2.s.r, c })];
    if (cell) cell.s = headerStyle;
  }

  if (data.length > 0) {
    xlsx.utils.sheet_add_json(ws1, data, { origin: 'A2', skipHeader: true });
  } else {
    ws1['A2'] = { v: 'No records found', t: 's' };
  }

  if (summaryData.length > 0) {
    xlsx.utils.sheet_add_json(ws2, summaryData, { origin: 'A2', skipHeader: true });
  } else {
    ws2['A2'] = { v: 'No records found', t: 's' };
  }

  ws1['!cols'] = logHeaders.map((header) => ({ width: Math.max(12, header.length + 2) }));
  ws2['!cols'] = summaryHeaders.map((header) => ({ width: Math.max(12, header.length + 2) }));

  xlsx.utils.book_append_sheet(wb, ws1, 'Print Logs');
  xlsx.utils.book_append_sheet(wb, ws2, 'Faculty Summary');

  return wb;
};

const buildReportPayload = async (targetMonth, targetYear) => {
  const logs = await PrintLog.findAll({
    where: { print_month: targetMonth, print_year: targetYear },
    include: [{ model: User, as: 'user', attributes: ['name', 'email', 'department', 'employee_id'] }],
    order: [['created_at', 'DESC']]
  });

  const data = logs.length > 0 ? logs.map((log, i) => ({
    'S.No': i + 1,
    'Faculty Name': log.user?.name || 'N/A',
    'Employee ID': log.user?.employee_id || 'N/A',
    'Department': log.user?.department || 'N/A',
    'Email': log.user?.email || 'N/A',
    'File Name': log.file_name,
    'Pages': log.num_pages,
    'Copies': log.copies,
    'Total Sheets': log.total_sheets,
    'Page Range': log.page_range,
    'Printer': log.printer_name,
    'Status': log.status,
    'Date & Time': new Date(log.created_at).toLocaleString()
  })) : [];

  const users = await User.findAll({ where: { role: 'faculty', is_active: true } });
  const summaryData = await Promise.all(users.map(async (u) => {
    const total = await PrintLog.sum('total_sheets', {
      where: { user_id: u.id, print_month: targetMonth, print_year: targetYear, status: 'success' }
    }) || 0;
    return {
      'Faculty Name': u.name,
      'Employee ID': u.employee_id || 'N/A',
      'Department': u.department || 'N/A',
      'Total Sheets Used': total,
    };
  }));

  return { data, summaryData };
};

// GET /api/admin/export - Export report to Excel
const exportReport = async (req, res) => {
  try {
    const { month, year } = req.query;
    const now = new Date();
    const targetMonth = parseInt(month) || now.getMonth() + 1;
    const targetYear = parseInt(year) || now.getFullYear();

    const { data, summaryData } = await buildReportPayload(targetMonth, targetYear);
    const workbook = formatReportWorkbook(data, summaryData);
    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const fileName = `PrintReport_${monthNames[targetMonth - 1] || 'Report'}_${targetYear}.xlsx`;

    const reportRecord = await Report.create({
      report_name: fileName,
      report_type: 'excel',
      generated_by: req.user.id,
      report_data: buffer,
      report_size: buffer.length,
      month: targetMonth,
      year: targetYear,
      created_at: new Date()
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('X-Report-Id', reportRecord.id);
    return res.send(buffer);
  } catch (error) {
    console.error('Export error:', error);
    return res.status(500).json({ success: false, message: 'Failed to export report.', error: error.message });
  }
};

const getReportById = async (req, res) => {
  try {
    const report = await Report.findByPk(req.params.id, {
      include: [{ model: User, as: 'generatedBy', attributes: ['name', 'email'] }]
    });

    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found.' });
    }

    const fileName = report.report_name || `report_${report.id}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    return res.send(report.report_data);
  } catch (error) {
    console.error('Download report error:', error);
    return res.status(500).json({ success: false, message: 'Failed to download report.', error: error.message });
  }
};

const listReports = async (req, res) => {
  try {
    const { month, year, search } = req.query;
    const where = {};

    if (month) where.month = month;
    if (year) where.year = year;
    if (search) {
      where.report_name = { [Op.like]: `%${search}%` };
    }

    const reports = await Report.findAll({
      where,
      include: [{ model: User, as: 'generatedBy', attributes: ['name', 'email'] }],
      order: [['created_at', 'DESC']]
    });

    return res.json({ success: true, reports: reports.map((report) => ({
      id: report.id,
      report_name: report.report_name,
      generated_by: report.generatedBy?.name || 'Unknown',
      generated_at: report.created_at,
      month: report.month,
      year: report.year,
      file_size: report.report_size
    })) });
  } catch (error) {
    console.error('List reports error:', error);
    return res.status(500).json({ success: false, message: 'Failed to list reports.', error: error.message });
  }
};

const deleteReport = async (req, res) => {
  try {
    const report = await Report.findByPk(req.params.id);
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found.' });
    }

    await report.destroy();
    return res.json({ success: true, message: 'Report deleted successfully.' });
  } catch (error) {
    console.error('Delete report error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete report.', error: error.message });
  }
};

// PUT /api/admin/users/:id - Update user details
const updateUser = async (req, res) => {
  try {
    const { name, department, employee_id } = req.body;
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    await user.update({ name, department, employee_id });
    return res.json({ success: true, message: 'User updated successfully.', user: user.toSafeObject() });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to update user.' });
  }
};


module.exports = { getAllUsers, toggleUserStatus, deleteUser, exportReport, updateUser, getReportById, listReports, deleteReport };
