const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');
const {
  getAllUsers, toggleUserStatus,
  deleteUser, exportReport, updateUser,
  getReportById, listReports, deleteReport
} = require('../controllers/adminController');

router.get('/users', authenticate, requireAdmin, getAllUsers);
router.put('/users/:id', authenticate, requireAdmin, updateUser);
router.put('/users/:id/toggle', authenticate, requireAdmin, toggleUserStatus);
router.delete('/users/:id', authenticate, requireAdmin, deleteUser);
router.get('/export', authenticate, requireAdmin, exportReport);
router.get('/reports', authenticate, requireAdmin, listReports);
router.get('/reports/:id/download', authenticate, requireAdmin, getReportById);
router.delete('/reports/:id', authenticate, requireAdmin, deleteReport);

module.exports = router;
