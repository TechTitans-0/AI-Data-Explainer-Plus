// Upload Controller - AI Data Explainer+

const fileService = require('../services/fileService');
const constants = require('../config/constants');

class UploadController {
    async upload(req, res) {
        try {
            if (!req.file) {
                return res.status(400).json({
                    success: false,
                    error: constants.ERRORS.NO_FILE_UPLOADED
                });
            }

            // Process the uploaded file
            const result = await fileService.processFile(req.file);

            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            console.error('Upload error:', error);
            res.status(500).json({
                success: false,
                error: error.message || constants.ERRORS.ANALYSIS_FAILED
            });
        }
    }
}

module.exports = new UploadController();
